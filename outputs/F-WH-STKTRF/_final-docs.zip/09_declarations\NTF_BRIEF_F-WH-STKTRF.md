# NTF_BRIEF — F-WH-STKTRF · Stock Transfer (ใบย้ายสินค้า)

> FRD sync 2026-09-17: event trigger points verified against `FRD_Pack/02_API.md` §2.3 and `03_LOGIC.md`; DOA-owned pending/result/escalation events remain excluded.

> ยิงผ่าน **ENG-NOTIFY (F-NOTIFY)** เท่านั้น — **ห้าม hardcode ช่องทาง/เงื่อนไขแจ้งเตือนใน feature**
> ⛔ **DOA events มาอัตโนมัติ ไม่อยู่ในใบนี้**: `doa_pending` · `doa_result` · `doa_escalate` — ประกาศซ้ำ = **BLOCK**
> ★ feature นี้มี DOA **2 จุดตัดสินใจ** (อนุมัติการย้าย · อนุมัติการตัดส่วนต่าง) → **ทั้งคู่ DOA engine ยิงเอง ไม่ประกาศที่นี่**
> ข้อความ template อยู่ในใบนี้ **ไม่ฝังใน code feature** · ทุก event มี `ref` (soft-reference ไปเอกสาร)

---

## 1. Identity

| ช่อง | ค่า |
|---|---|
| feature_id | `F-WH-STKTRF` (fid F083) |
| ชื่อ | Stock Transfer — ใบย้ายสินค้า |
| module | Warehouse (WH) |
| event prefix | `transfer_` |
| wire_status | `pending` |

---

## 2. Event ที่ประกาศ (event ธุรกิจของ feature เอง)

| # | Event ID | Trigger (อ้าง PREBRIEF) | ผู้รับ | ข้อความ template | Channel default | ปิดได้ |
|---|---|---|---|---|---|---|
| 1 | ★ `transfer_shipped` | `อนุมัติแล้ว → ส่งออกแล้ว — อยู่ระหว่างทาง` · **โหมดข้ามคลังเท่านั้น** (§5.1 · S-01 ขา 1) | ★ **เจ้าหน้าที่ + หัวหน้าคลังปลายทาง** · ผู้จัดทำใบ | **{trf_no}** ส่งของออกจาก {wh_from} แล้ว — {line_count} รายการ กำลังเดินทางมาที่ {wh_to} · **กรุณายืนยันรับเมื่อของถึง** | in-app + email | ✗ **บังคับ** |
| 2 | `transfer_moved_intra` | `อนุมัติแล้ว → ย้ายสำเร็จ` · **โหมดภายในคลังเท่านั้น** (§5.1 · S-02) | ผู้จัดทำใบ · หัวหน้าคลัง | **{trf_no}** ย้ายสินค้าภายในคลัง {wh_from} สำเร็จ — {line_count} รายการ | in-app | ✓ |
| 3 | ★ `transfer_partially_received` | `ส่งออกแล้ว → รับบางส่วน` (§5.1 · S-06 · BR-16) | ★ **หัวหน้าคลังต้นทาง** · ผู้จัดทำใบ · หัวหน้าคลังปลายทาง | **{trf_no}** ปลายทางรับแล้ว {qty_received}/{qty_shipped} — **ยังค้างระหว่างทาง {qty_in_transit} {uom_summary}** | in-app + email | ✗ **บังคับ** |
| 4 | `transfer_received` | `ส่งออกแล้ว/รับบางส่วน → ปิดใบ (รับครบ)` (§5.1 · S-01 ขา 2) | ผู้จัดทำใบ · หัวหน้าคลังต้นทาง | **{trf_no}** ปลายทาง {wh_to} รับของครบแล้ว — ปิดใบเรียบร้อย | in-app | ✓ |
| 5 | ★ `transfer_shortage_written_off` | `→ ปิดใบพร้อมส่วนต่าง` **หลัง DOA สาย B1 อนุมัติครบ** (§5.1 · S-07 · BR-18) | ★ **หัวหน้าคลังต้นทาง + ปลายทาง · ผู้จัดการคลังสินค้า · บัญชี** | **{trf_no}** ตัดส่วนต่างระหว่างทาง {qty_shortage} {uom_summary} — มูลค่า **{shortage_amount} บาท** (เหตุผล: {shortage_reason}) | in-app + email | ✗ **บังคับ** |
| 6 | ★ `transfer_returned_to_source` | `→ ตีกลับคืนต้นทางแล้ว` (§5.1 · S-08 · BR-19) | ★ **หัวหน้าคลังต้นทาง** · ผู้จัดทำใบ | **{trf_no}** ปลายทาง {wh_to} ตีกลับของคืน — ของกลับเข้า {bin_source_summary} แล้ว (เหตุผล: {return_reason}) | in-app + email | ✗ **บังคับ** |
| 7 | ★ `transfer_in_transit_aging` | **เกณฑ์ NC rules** — ใบสถานะ `ส่งออกแล้ว`/`รับบางส่วน` ที่ `อายุค้างระหว่างทาง > เกณฑ์` (§3.3 · S-09 · BR-27) | หัวหน้าคลังต้นทาง + ปลายทาง · ผู้จัดการคลังสินค้า | **{trf_no}** ค้างระหว่างทางมา {aging_days} วันแล้ว — ของ {qty_in_transit} {uom_summary} ยังไม่ถึง {wh_to} | in-app + email | ✓ |
| 8 | `transfer_reversed` | `ใบปิดแล้ว → กลับรายการแล้ว` (§5.1 · S-15 · BR-26) | ผู้จัดทำใบ · หัวหน้าคลังต้นทาง + ปลายทาง · บัญชี | **{trf_no}** ถูกกลับรายการโดย {actor_name} (เหตุผล: {reversal_reason}) — สร้างใบกลับรายการ **{reversal_trf_no}** | in-app + email | ✗ **บังคับ** |
| 9 | `transfer_cancelled` | `ร่าง/รออนุมัติ/อนุมัติแล้ว → ยกเลิก` (§5.1 · S-13 · BR-21) | ผู้จัดทำใบ · ผู้อนุมัติที่ค้างอยู่ในสาย | **{trf_no}** ถูกยกเลิกก่อนส่งของ (เหตุผล: {cancel_reason}) | in-app | ✓ |

> ★ **event 1 · 3 · 5 · 6 เป็น "ปิดไม่ได้" โดยเจตนา** — ทั้ง 4 ตัวเกี่ยวกับ **ช่วงที่ของอยู่ในมือใครไม่ชัด (in-transit)** ซึ่งเป็นความเสี่ยงหลักของ feature นี้ · ถ้าให้ปิดได้ ของอาจค้างระหว่างทางโดยไม่มีใครรู้ (PREBRIEF BR-15 · S-09)
> ★ **event 1 คือหัวใจของ 2 ขา** — ถ้าไม่ยิงตัวนี้ คลังปลายทางจะไม่รู้ว่ามีของกำลังมา แล้วใบจะไม่มีวันถูกปิด (OB-4)

---

## 3. Event ที่ **ไม่** ประกาศ + เหตุผล

| ไม่ประกาศ | เหตุผล |
|---|---|
| `doa_pending` / `doa_result` / `doa_escalate` (**สาย A1/A2 อนุมัติการย้าย**) | ⛔ **DOA engine เป็นเจ้าของ** — ยิงให้อัตโนมัติตอนส่งอนุมัติ/อนุมัติ/ตีกลับ · ประกาศซ้ำ = BLOCK |
| `doa_pending` / `doa_result` (**สาย B1 อนุมัติการตัดส่วนต่าง**) | ⛔ **DOA engine เป็นเจ้าของเช่นกัน** — ถึงจะเป็นจุดตัดสินใจที่ 2 ก็ยังเป็น DOA event · **event 5 `transfer_shortage_written_off` ที่ประกาศไว้คือ "ผลหลังตัดสำเร็จ" ไม่ใช่ "ขออนุมัติ"** — คนละจังหวะ ไม่ซ้ำกัน |
| `ร่าง → รออนุมัติ` (ตัวใบเอง) | ไม่มีผลทางธุรกิจ + DOA engine ยิง `doa_pending` ให้แล้ว |
| แจ้งเตือนตอนสร้างร่าง / บันทึกร่าง | ไม่มีใครต้องรู้ (S-03) |
| แจ้งเตือน "ยอดต้นทางเปลี่ยน" (S-28) | เป็น **validation ในหน้าจอ** ไม่ใช่ notification — เตือนสด ๆ ตอนกดส่งออก (BR-20) |
| แจ้งเตือนของ Location Master / Item Master | เป็นของ feature อื่น — soft-ref อ่านอย่างเดียว |

---

## 4. Payload contract (ตัวแปรในข้อความ — ต้องมีจริงใน entity ตาม PREBRIEF §3)

| ตัวแปร | ที่มา | หมายเหตุ |
|---|---|---|
| `ref` = `trf_id` | header | soft-reference ทุก event (บังคับ) |
| `{trf_no}` | doccfg `TRF-YYYY-NNNN` (§3.1) | ปี **ค.ศ.** · ร่างยังไม่มีเลข → event 9 ที่ยิงจากร่างให้ใช้ `(ร่าง)` |
| `{wh_from}` / `{wh_to}` | §3.1 คลังต้นทาง / คลังปลายทาง (soft-ref) | แสดงชื่อคลัง ไม่ใช่รหัสล้วน |
| `{transfer_mode}` | §3.1 derive (`ภายในคลัง`/`ข้ามคลัง`) | ใช้เลือกว่ายิง event 1 หรือ event 2 |
| `{line_count}` | นับบรรทัด | — |
| `{qty_shipped}` / `{qty_received}` / `{qty_in_transit}` | §3.2 · §3.3 | ★ `qty_in_transit` = `Σ คงค้างระหว่างทาง` |
| `{qty_shortage}` / `{shortage_amount}` / `{shortage_reason}` | §3.2 · §3.3 | ★ **ไม่รวมส่วนที่ตีกลับคืนต้นทาง** (BR-19) |
| `{return_reason}` / `{cancel_reason}` / `{reversal_reason}` | เหตุผลบังคับตาม BR-19 / BR-21 / BR-26 | — |
| `{bin_source_summary}` | §3.2 bin ต้นทาง | ใช้ใน event 6 |
| `{aging_days}` | §3.3 อายุค้างระหว่างทาง | ★ **เกณฑ์อยู่ NC rules ไม่อยู่ feature** (BR-27) |
| `{uom_summary}` | §3.2 UOM (soft-ref) | หลายหน่วยในใบเดียว → สรุปเป็น "รายการ" |
| `{actor_name}` | ผู้ทำรายการ (**คนจริง**) | ห้ามใช้ role ID |
| `{reversal_trf_no}` | §3.1 soft link ใบกลับรายการ | — |

---

## 5. เพิ่มเข้า Event Catalog (F-NOTIFY EVENT_GROUPS)

- กลุ่ม **"เอกสารธุรกรรม"** → ใช้ `doc_status` เดิม สำหรับ event 2 · 4 · 9 (ไม่เพิ่มกลุ่มใหม่)
- ★ กลุ่ม **"คลังสินค้า — ของระหว่างทาง"** → **เสนอเพิ่มใหม่** สำหรับ event 1 · 3 · 5 · 6 · 7
  เหตุผล: เป็นสถานะที่ **ไม่มี feature ไหนในระบบเคยมี** — ของอยู่ในมือกิจการแต่ไม่อยู่ในคลังไหนเลย · ผู้รับหลักคือ **คลังปลายทาง** ซึ่งไม่ใช่ผู้เกี่ยวข้องกับเอกสารตามนิยามเดิม (ผู้สร้าง/ผู้อนุมัติ) จึงต้องมีกลุ่มของตัวเองเพื่อให้ผู้ใช้ตั้ง preference ได้ตรง
- event 8 `transfer_reversed` → ใช้กลุ่ม **"การกลับรายการ/แก้ไขย้อนหลัง"** เดิม (กลุ่มเดียวกับ StockAdj `adj_reversed`) — **ไม่เพิ่มใหม่**

> ⚠️ **Sync Read**: ก่อน register จริง ต้องเช็คกับ `f-doccfg`/`f-notify` EVENT_GROUPS ปัจจุบัน — ถ้ามีกลุ่มที่ความหมายซ้อนอยู่แล้ว **ใช้ตัวเดิม ห้ามสร้างซ้ำ**

---

## 6. Dev wiring note

- จุดเรียก: `ENG-NOTIFY.emit(event_id, { ref: trf_id, vars: {...} })` **ที่ transition ตาม trigger ใน §2** — **ห้ามเช็ค preference เอง ห้ามเลือก channel เอง**
- ★ event 1 vs event 2 เลือกจาก `transfer_mode` ที่ derive แล้ว (BR-03) — **ห้ามให้ผู้ใช้เลือกโหมดเอง**
- ★ event 7 `transfer_in_transit_aging` เป็น **scheduled evaluation** ไม่ใช่ transition — engine อ่านเกณฑ์จาก **NC rules** แล้วประเมินเอง · feature แค่เปิด field `อายุค้างระหว่างทาง` ให้อ่าน (BR-27)
- ★ ห้ามยิง event 5 ก่อน **DOA สาย B1 อนุมัติครบ** — ลำดับคือ `ขออนุมัติตัด → doa_result (engine) → ตัดสำเร็จ → transfer_shortage_written_off`
- ในรอบ Phase A (HTML prototype) จุดเรียกทั้งหมดเป็น mock + marker **`FWD-WIRE: ENG-NOTIFY`**

---

## 7. Open Questions

| # | คำถาม | ค่าที่ใช้รอบนี้ | ใครต้องตอบ |
|---|---|---|---|
| **NTF-Q1** | กลุ่ม event ใหม่ "คลังสินค้า — ของระหว่างทาง" ควรมีจริงไหม หรือยัดกลุ่มเอกสารธุรกรรมเดิม | **เสนอเพิ่มใหม่** `[AI-DRAFT]` | เจ้าของ F-NOTIFY |
| **NTF-Q2** | event 1/3/5/6 ปิดไม่ได้ — เข้มเกินไปไหม | **คงไว้** — เป็นความเสี่ยงหลักของ feature `[AI-DRAFT]` | **Strike** |
| **NTF-Q3** | ผู้รับ event 5 ควรรวมบัญชีด้วยไหม (เป็นผลขาดทุนจริง) | **รวม** — เพราะกระทบ JE ตอน W5 `[AI-DRAFT]` | **Strike / W5** |
| **NTF-Q4** | เกณฑ์ aging ระหว่างทาง (กี่วันถือว่าเสี่ยง) | **อยู่ NC rules** — feature ไม่เก็บเลข (BR-27) | เจ้าของ NC rules |
