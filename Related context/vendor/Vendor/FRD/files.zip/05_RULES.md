# 05_RULES — F-VENDOR-MASTER-001 Vendor Master

> Audience: BE Dev (validation impl), QA (test design), BA (consistency)
> Source: BRD §9 (28 rules) + state machine §8 + edge cases §10

## §5.1 Business Rules (BR)

### Core Validation Rules

| ID | Rule | Tag | Implementation |
|---|---|---|---|
| BR-V01 | tax_id ต้อง 13 หลัก + ผ่าน checksum (TH) | FIXED | FN-14 validateVendorInput |
| BR-V02 | tax_id unique ต่อ country (per tenant) | FIXED | DB UQ partial constraint (§4.2) |
| BR-V03 | tax_id ของ OT vendor → optional | FIXED | FN-14 conditional |
| BR-V04 | vendor code auto-gen `V-{CC}-{TT}-{NNNNN}` running per country+type | FIXED | FN-13 genVendorCode + ENG-CODE-GEN |
| BR-V05 | vendor name required, ≤255 chars | FIXED | FN-14 + DB NOT NULL |
| BR-V06 | bank account number 10-15 digits | CONFIGURABLE | FN-14 (per-bank length from Bank master, Phase 1.5) |
| BR-V07 | non-OT vendor requires ≥1 verified bank before approval | FIXED | FN-17 paidVendorNeedsBank + FN-05 guard |
| BR-V08 | ≥1 contact with email + phone before approval | FIXED | FN-16 hasValidContact + FN-05 guard |
| BR-V09 | credit limit ≥ 0 | FIXED | FN-14 (numeric > 0) |

### KYC & Sanctions Rules

| ID | Rule | Tag | Implementation |
|---|---|---|---|
| BR-K01 | vendor must have kyc=passed before approval | FIXED | FN-05 guard (`KYC_NOT_PASSED`) |
| BR-K02 | sanctions hit auto-blocks vendor | FIXED | FN-04 reviewKyc — when sanctions_hit=true → status=blocked |
| BR-K03 | tax_id immutable after kyc=passed (IR-01) | FIXED | FN-15 isImmutableTax + FN-02 guard (`IMMUTABLE_TAX_ID`) |
| BR-K04 | only Compliance/Admin can review KYC | FIXED | API-06 role check |
| BR-K05 | KYC scope = attachments + tax format + sanctions screening | CONFIGURABLE | ENG-SANCTIONS (Compliance + Policy Center later) |

### Approval Rules

| ID | Rule | Tag | Implementation |
|---|---|---|---|
| BR-A01 | approver ≠ creator (SoD-01) | FIXED | FN-07 guard (`SOD_VIOLATION`) |
| BR-A02 | role must match current step (or Director/Admin override) | DYNAMIC | FN-18 canApproveCurrent — wires to ENG-DOA-CHAIN Phase 2 |
| BR-A03 | approval chain rule based on creditLimit | **DYNAMIC** | Phase 1: inline placeholder in FN-05. Phase 2: ENG-DOA-CHAIN |
| BR-A04 | OT vendor → chain=[] (auto-approve) | FIXED | FN-06 autoApproveOneTime |
| BR-A05 | reject → status=pending_kyc + clear approvalChain | FIXED | FN-08 rejectApproval |

### Masking & Permission Rules

| ID | Rule | Tag | Implementation |
|---|---|---|---|
| BR-M01 | tax_id classification = Confidential | FIXED | API masking middleware + UI `maskTax()` |
| BR-M02 | bank.acct classification = Restricted | FIXED | API + UI `maskAcct()` + AES-256 at rest |
| BR-M03 | mask pattern: tax `4+dots+2`, bank `3+dots+2` | CONFIGURABLE | Phase 2: ENG-DATA-CLASSIFICATION config |

### Lifecycle Rules

| ID | Rule | Tag | Implementation |
|---|---|---|---|
| BR-L01 | blacklisted = terminal (one-way, no UI to leave) | FIXED | UI: no action button when status=blacklisted; API-11/12/04 reject when status=blacklisted |
| BR-L02 | edit allowed only when status ∈ {prospect, pending_kyc, active} | FIXED | UI: canEdit() check; API-04 status guard |
| BR-L03 | block/unblock/blacklist/reject ต้องมี reason | FIXED | API-09/11/12/13 body validation (min 5 chars) |
| BR-L04 | vendor with hasTxn=true → soft-block only | FIXED | API-11 block sets status=blocked (not delete); vendor_id retained as match key |

### Special Rules (numbered S-series for cross-feature reference)

| ID | Rule | Tag | Notes |
|---|---|---|---|
| BR-S06 | Sanctions hit during KYC → auto-block + reason='sanctions hit' | FIXED | FN-04, audit critical |
| BR-S07 | Audit write failure → rollback transaction | FIXED | DB transaction + critical alert |

### Cross-Feature Rules (numbered X-series — Vendor Master ↔ other features) ⭐ NEW v1.1

| ID | Rule | Tag | Notes |
|---|---|---|---|
| BR-X01 | Tab 5 fetches Price List summary via ENG-PRICE-LIST-PROXY only — **no direct DB read** | FIXED | enforces data ownership boundary; FN-20 implementation |
| BR-X02 | Tab 5 UI has **no edit/add/delete buttons** — read-only enforced at UI layer | FIXED | UI/UX boundary; all mutations require user navigate to F-VENDOR-PRICE-LIST |
| BR-X03 | API-16 strips fields not used by Tab 5 (category, minQty, validFrom, validTo) — only returns 5 fields | FIXED | reduces payload + clarifies contract; ENG-PRICE-LIST-PROXY enforces |
| BR-X04 | Price List Summary cached 5 min (Redis); invalidated on F-VENDOR-PRICE-LIST publish event | CONFIGURABLE | TTL configurable per env; Phase 2 wires invalidation |
| BR-X05 | F-VENDOR-PRICE-LIST API unavailable → API-16 returns 502 + UI shows fallback "ไม่สามารถดึง Price List ได้" — vendor still functional | FIXED | resilience: Tab 5 failure does NOT block other vendor operations |
| BR-X06 | Tab 5 view permission = vendor:read (all 6 roles) — no separate Price List ACL in Vendor Master | FIXED | Price List itself may have its own permission model; Vendor Master delegates |

## §5.2 State Machine

### Vendor lifecycle (6 states + state diagram)

```
                                  ┌──────────────────┐
                                  │     prospect     │ (initial)
                                  └────────┬─────────┘
                                  ส่ง KYC  │ submit-kyc
                                           ▼
        sanctions hit          ┌──────────────────┐
        (auto)                 │   pending_kyc    │
       ◄────────────┬──────────└────────┬─────────┘
                    │            KYC ผ่าน + ส่งอนุมัติ │ submit-approval
                    │            (non-OT)             │
                    │                                 ▼
                    │                ┌──────────────────────┐
                    │                │  pending_approval    │
                    │                └─────┬─────────────────┘
                    │            ตีกลับ    │ chain done │ OT auto
                    │     (clear chain)   │            │ skip→
                    │     ┌───────────────┘            │
                    │     ▼                            ▼
                    │  (back to pending_kyc)    ┌──────────┐
                    │                          │  active   │ ◄────┐
                    │                          └────┬─────┘      │
                    ▼                       บล็อก   │ block      │ ปลด
              ┌──────────┐                          ▼            │ unblock
              │ blocked  │ ◄───────────────────────────────────┘
              └─────┬────┘
                    │ แบล็คลิสต์ (Director only)
                    ▼
              ┌─────────────┐
              │ blacklisted │ ← (terminal, one-way)
              └─────────────┘
```

### Transition Table (state × event)

| Current State | Event (API/Action) | Guards | Next State | Side Effects |
|---|---|---|---|---|
| (none) | API-03 Create | RBAC: Officer/Admin + valid input | prospect | INSERT vendor, audit `created` |
| prospect | API-05 submit-kyc | RBAC | pending_kyc | UPDATE status, audit `submitted_for_kyc` |
| prospect | API-04 edit | canEdit | prospect | UPDATE fields + version++, audit `updated` |
| prospect | API-11 (n/a) | — | — | (no block from prospect) |
| pending_kyc | API-06 kyc-review (pass) | Compliance | pending_kyc (kyc=passed, tax locked) | audit `kyc_passed` |
| pending_kyc | API-06 kyc-review (fail) | Compliance | pending_kyc (kyc=failed) | audit `kyc_failed` |
| pending_kyc | API-06 kyc-review (sanctions hit) | (System) | blocked | audit `sanctions_hit_auto_block` |
| pending_kyc | API-07 submit-approval (non-OT) | kyc=passed + contact + bank | pending_approval | build chain, audit `submitted_for_approval` |
| pending_kyc | API-07 submit-approval (OT) | kyc=passed + contact | active | audit `ot_auto_approved` |
| pending_kyc | API-04 edit | canEdit + IR-01 (no tax change) | pending_kyc | audit `updated` |
| pending_approval | API-08 approve (mid-chain) | canApproveCurrent + SoD + KYC | pending_approval (step approved) | mark step, audit `approved_step_N` |
| pending_approval | API-08 approve (final step) | (chain done) | active | audit `chain_complete` |
| pending_approval | API-09 reject | canApproveCurrent + reason | pending_kyc (chain=[]) | clear chain, audit `rejected — <reason>` |
| active | API-11 block | canBlock + reason | blocked | audit `blocked — <reason>` |
| active | API-13 blacklist | canBlacklist + reason | blacklisted | audit `blacklisted — <reason>` |
| active | API-04 edit | canEdit | active | audit `updated` |
| blocked | API-12 unblock | canBlock + reason | active | audit `unblocked — <reason>` |
| blocked | API-13 blacklist | canBlacklist + reason | blacklisted | audit `blacklisted — <reason>` |
| blacklisted | (any mutation) | — | (rejected) | API returns 409 `TERMINAL_STATE` |

## §5.3 Permission Matrix

(See BRD §4.1 — repeated here for FRD self-containment)

| Role | API-01 List | API-02 Get | API-03 Create | API-04 Edit | API-05 Submit KYC | API-06 KYC Review | API-07 Submit Approval | API-08 Approve | API-09 Reject | API-10 Verify Bank | API-11 Block | API-12 Unblock | API-13 Blacklist | API-14 Audit |
|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| Procurement Officer | ✅ | ✅ (masked) | ✅ | ✅ | ✅ | ❌ | ✅ | (step 1 only) | (step 1) | ❌ | ✅ | ✅ | ❌ | ❌ |
| Procurement Manager | ✅ | ✅ (masked) | ❌ | ❌ | ❌ | ❌ | ❌ | (step 1-2) | (step 1-2) | ❌ | ✅ | ✅ | ❌ | ❌ |
| Procurement Director | ✅ | ✅ (masked) | ❌ | ❌ | ❌ | ❌ | ❌ | (any) | (any) | ❌ | ✅ | ✅ | ✅ | ❌ |
| Finance | ✅ | ✅ (full) | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ |
| Compliance | ✅ | ✅ (full tax) | ❌ | ❌ | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |
| Admin | ✅ | ✅ (full) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ (override) | ✅ (override) | ✅ | ✅ | ✅ | ✅ | ✅ |
| Internal Audit | ✅ | ✅ (masked) | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |

## §5.4 Field Validation Rules

### Per-field declarative rules

| Field | Validation |
|---|---|
| `name` | `required`, `maxLength: 255` |
| `type` | `required`, `enum: ['RM','TR','SV','MN','CT','LG','SP','UT','GV','EM','OT']` |
| `country` | `required`, `match: /^[A-Z]{2}$/`, `existsIn: country_master` |
| `tax_id` | (non-OT) `required`, `match: /^\d{13}$/`, `tax_checksum_th` (if country=TH), `unique per (tenant, country)` |
| `tax_id` (after kyc=passed) | `immutable` (IR-01) |
| `currency` | `required`, `match: /^[A-Z]{3}$/`, `existsIn: currency_master` |
| `term` | `required`, `existsIn: payment_terms_master` (Finance) |
| `wht` | optional, `numeric`, `min: 0`, `max: 30` |
| `credit_limit` | optional, `numeric`, `min: 0` |
| `contacts[i].email` | optional, `email_format` |
| `contacts[i].phone` | optional, `phone_format` |
| `banks[i].acct` | `required`, `match: /^\d{10,15}$/` |
| `addresses[i].line` | (if address present) `required`, `maxLength: 500` |
| `addresses[i].postal` | (if province given) `match: /^\d{5}$/` |

### Cross-field rules

| ID | Rule |
|---|---|
| CR-01 | Exactly one address has `is_billing=true` (DB partial UQ + UI exclusive toggle) |
| CR-02 | At most one address has `is_primary_shipping=true` |
| CR-03 | Exactly one bank has `is_primary=true` (if banks.length > 0) |
| CR-04 | OT vendor: tax_id optional but if provided must validate |
| CR-05 | Contact role 'primary' should exist (warning, not error) |

## §5.5 Edge Cases

### From BRD §10.1 (BA-identified)

| ID | Case | Expected | Test Case |
|---|---|---|---|
| EC-01 | Create vendor with duplicate tax_id in same country | Block — toast `DUPLICATE_TAX_ID` | TC-EC-01 |
| EC-02 | OT vendor without tax_id, rest filled | OK — UI shows `ยกเว้น` | TC-EC-02 |
| EC-03 | Submit approval when kyc=pending/failed | Block — `KYC_NOT_PASSED` | TC-EC-03 |
| EC-04 | Submit approval without contact (email+phone) | Block — `NOT_READY · contact` | TC-EC-04 |
| EC-05 | Submit approval without verified bank (non-OT) | Block — `NOT_READY · bank` | TC-EC-05 |
| EC-06 | Same user creates and tries to approve | Block — `SOD_VIOLATION` | TC-EC-06 |
| EC-07 | Officer attempts to approve step requiring Director | Block — `WRONG_APPROVER · ผู้อำนวยการจัดซื้อ` | TC-EC-07 |
| EC-08 | KYC review detects sanctions match | Auto: kyc=failed + status=blocked + reason | TC-EC-08 |
| EC-09 | Edit tax_id after KYC pass | Field disabled in UI + API returns `IMMUTABLE_TAX_ID` | TC-EC-09 |
| EC-10 | Reject vendor mid-chain (step 1 approved, step 2 pending) | status→pending_kyc + chain=[] | TC-EC-10 |
| EC-11 | Block vendor with active transactions (hasTxn=true) | OK — soft-block, vendor_id retained | TC-EC-11 |
| EC-12 | Attempt to unblock blacklisted vendor | 409 `TERMINAL_STATE` | TC-EC-12 |
| EC-13 | Active vendor: delete last verified bank | Vendor stays active; PV gate blocks until new bank verified | TC-EC-13 |

### From BRD §10.2 (AI patterns)

| Pattern | Case | Expected | Test Case |
|---|---|---|---|
| FU | Non-TH country tax format | Use country-specific regex (Phase 2 — TH-only Phase 1) | TC-EC-14 |
| **CA** | Two users approve same step concurrently | Optimistic concurrency: version mismatch → 409 + reload | TC-EC-15 |
| EM | Vendor with no contact/bank/address at all | OK as prospect; gate at submit-approval | TC-EC-16 |
| **DI** | Network drop during confirmApprove | Retry safe — idempotency key prevents double-approval | TC-EC-17 |
| CL | Vendor "retire" (not blacklist) | Phase 2: inactive state. Phase 1 workaround: block with reason="retired" | (deferred) |
| **ST** | Edit in tab A while tab B blocks vendor | version mismatch → toast `STALE_VERSION · refresh` | TC-EC-18 |
| PD | PDPA delete request | Phase 2: anonymize tool | (deferred) |
| PM | Role lowered mid-session | re-evaluate per render; API rejects with `FORBIDDEN` on next action | TC-EC-19 |
| EN | Vendor name with emoji/special chars | escape via `esc()` (XSS); store as-is in DB (UTF-8) | TC-EC-20 |

## §5.6 Error Catalog

| Code | HTTP | Message Thai | When |
|---|---|---|---|
| `KYC_NOT_PASSED` | 422 | ต้องผ่าน KYC ก่อนส่งอนุมัติ | Submit before KYC pass |
| `NOT_READY` | 422 | ข้อมูลไม่พร้อม (contact/bank) | Submit without prerequisites |
| `SOD_VIOLATION` | 422 | ผู้อนุมัติต้องไม่ใช่ผู้สร้าง | approver = creator |
| `WRONG_APPROVER` | 422 | ขั้นนี้ต้อง {role label} | Wrong role for step |
| `DUPLICATE_TAX_ID` | 409 | เลขภาษีนี้มีคู่ค้าอื่นใช้แล้วในประเทศนี้ | UQ violation |
| `IMMUTABLE_TAX_ID` | 422 | ล็อกเลขภาษี (IR-01) — แก้ไม่ได้หลังผ่าน KYC | Edit tax after KYC pass |
| `REASON_REQUIRED` | 422 | กรุณาระบุเหตุผล | Block/blacklist/reject/unblock w/o reason |
| `INVALID_TRANSITION` | 409 | สถานะปัจจุบันไม่อนุญาตการดำเนินการนี้ | Wrong state for action |
| `TERMINAL_STATE` | 409 | สถานะนี้เป็น terminal — แก้ไขไม่ได้ | Any action on blacklisted |
| `STALE_VERSION` | 409 | ข้อมูลถูกแก้โดยผู้อื่น — โปรด refresh | Optimistic lock conflict |
| `FORBIDDEN` | 403 | ไม่มีสิทธิ์ | RBAC denial |
| `BLACKLIST_REQUIRES_DIRECTOR` | 403 | แบล็คลิสต์ต้องทำโดย Procurement Director | Lower role blacklist attempt |
| `AUDIT_WRITE_FAILED` | 500 | บันทึก audit ไม่สำเร็จ — โปรดลองใหม่ | DB issue (critical alert) |
| `IDEMPOTENCY_CONFLICT` | 409 | Idempotency key reuse with different body | Idempotency violation |
| `VALIDATION_FAILED` | 422 | (per-field errors array) | Field validation |

## §5.7 Security Bible Application + Data Classification Enforcement

### D-CLASS Summary (Enforcement per feature)

| Field | Classification | DB | API | UI | Audit |
|---|---|---|---|---|---|
| tax_id | Confidential | (plain) | mask for non-Finance/Compl/Admin | UI mask + 🔒 if locked | read access logged Phase 2 |
| vat | Confidential | (plain) | mask same | UI mask | — |
| company_reg | Confidential | (plain) | mask same | UI mask | — |
| credit_limit | Confidential | (plain) | hide for non-Finance/Compl/Admin | label "ปกปิด" | — |
| bank.acct | **Restricted** | AES-256 at rest | mask for non-Finance/Admin | UI mask | read alert > N reads/hour |

### D2 Authentication & Session
- SSO via CUBE Auth + MFA required for all roles
- Session timeout: 8 hours (configurable)
- Refresh token: 30 days (revocable on role change)

### D3 Authorization
- RBAC enforced at API gateway middleware
- Each API spec has `requires: [roles]` annotation
- Permission re-evaluated per request (PM edge case mitigation)

### D6 Logging & Monitoring
- All mutation APIs write WORM audit (event_type, actor, at, meta)
- Audit table: INSERT-only DB grant
- Audit retention: 7 years
- Monitoring: failed audit writes → critical alert + transaction rollback

### D9 Privacy (PDPA)
- PII fields marked in §4.6.4
- Right to access: API-02 (user can request own data — different API for vendors as data subjects in Phase 3)
- Right to deletion: Phase 2 anonymization tool (PII set to anonymized; transactional retained)

### D10 Regulatory
- ISO 27001 controls A.5.15, A.8.2, A.8.34 covered
- SOC 2 CC6.1, CC7.2 covered
- AML/Sanctions: ENG-SANCTIONS integration mandatory

---

**Cross-reference verification:**
- BR rule count: 28 (matches BRD §9)
- Edge cases: 13 BA + 7 AI (rest deferred to Phase 2/3) = 20 active
- All BR have implementation trace to FN/Engine/DB constraint
