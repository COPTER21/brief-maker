# 07_LOCKED_DECISIONS — F-VENDOR-MASTER-001 Vendor Master

> Locked Decisions (LD) = key choices documented to prevent re-litigation
> Convention Deviations (CD) = deliberate departures from CUBE standards (each w/ rationale)
> Tradeoffs = acknowledged costs of chosen approach

## §7.1 Locked Decisions (LD)

### LD-01: Use optimistic locking, not pessimistic
- **Decision:** All PATCH endpoints use `If-Match: {version}` header with auto-increment version column
- **Rationale:** PostgreSQL row locks introduce contention on hot vendors (e.g., V001 referenced by many PRs simultaneously). Optimistic is cheaper for read-heavy workloads, and concurrent edits are rare in practice
- **Tradeoff accepted:** users see `STALE_VERSION` 409 errors during concurrent edits — UI must surface "ข้อมูลถูกแก้โดยผู้อื่น" with refresh button
- **Date locked:** 2026-05-29
- **Decided by:** Architect (with BE Lead consultation)

### LD-02: Store approval_chain as JSONB in T_vendor (not separate table)
- **Decision:** `T_vendor.approval_chain` is a JSONB column holding the snapshot of DOA chain steps
- **Rationale:**
  - Chain is always read with vendor (1:1 ownership) — JOIN cost not worth it
  - Chain shape varies (1, 2, or more steps depending on DOA rule) — JSONB is flexible
  - Audit history is in T_vendor_audit (no need for separate chain history table)
- **Tradeoff:** GIN index on JSONB for "approval queue for me" query is more complex than relational query; query plan must be validated under load
- **Future:** Phase 2+ may extract to `T_vendor_approval_chain` if reporting needs grow
- **Date locked:** 2026-05-29
- **Decided by:** Architect + DBA

### LD-03: DOA chain — Phase 1 inline placeholder, Phase 2 wire to ENG-DOA-CHAIN ⭐
- **Decision:** Phase 1 implements DOA chain rule as inline function in FN-05 (`resolveApprovalChain`). Phase 2 swaps to `ENG-DOA-CHAIN` engine (Policy Center) with no UI change
- **Phase 1 inline rule (current):**
  ```js
  if (type === 'OT') → chain=[]
  if (creditLimit > 5,000,000) → chain=[Manager, Director]
  if (creditLimit > 1,000,000) → chain=[Manager]
  else → chain=[Officer]
  ```
- **Phase 2 migration:**
  - Call `ENG-DOA-CHAIN.resolve({entity:"vendor", attributes:{creditLimit, type, country}})`
  - Engine returns same shape: `[{seq, role, label, status, ...}]`
  - UI/API contract unchanged
- **Rationale:** Vendor module is foundational P2P feature — must ship in Phase 1 even before Policy Center wave is built. Placeholder rule covers ~80% of expected scenarios; remaining 20% addressed in Phase 2
- **Risk:** Phase 1 vendors approved under placeholder rule may need re-approval if Phase 2 rule is stricter — mitigation: keep approval_chain snapshot so historical decisions are preserved
- **Promoted from:** OQ-01
- **Date locked:** 2026-05-29
- **Decided by:** Architect + BA Lead + Policy Center team

### LD-04: Data Classification — Phase 1 hardcoded mask, Phase 2 wire to ENG-DATA-CLASSIFICATION ⭐
- **Decision:** Phase 1 uses hardcoded `maskTax()`, `maskAcct()`, `canSeeTax()`, `canSeeBankNo()` functions per feature. Phase 2 replaces with engine call using per-column classification config
- **Phase 1 mask patterns (locked):**
  - tax_id: 4 prefix + dots (6 chars) + 2 suffix → `0105••••••67`
  - bank.acct: 3 prefix + dots (4 chars) + 2 suffix → `0123••••89`
  - creditLimit: hidden entirely (no partial reveal) — UI shows "ปกปิด"
- **Role-to-classification visibility (locked):**
  - **Confidential (tax_id, vat, companyReg, creditLimit):** visible to Finance, Compliance, Admin; masked for Procurement (3 levels)
  - **Restricted (bank.acct):** visible to Finance, Admin only; masked for Procurement + Compliance
- **Phase 2 migration:** call `ENG-DATA-CLASSIFICATION.mask(record, schema, actorRole)` — schema config replaces hardcoded role checks
- **Rationale:** Same as LD-03 — foundational feature must ship before Policy Center wave
- **Promoted from:** OQ-02
- **Date locked:** 2026-05-29
- **Decided by:** Architect + Security Lead

### LD-05: Inline-to-Engine Migration Plan (zero-downtime)
- **Decision:** All Phase 1 placeholder logic for DOA + Classification + Sanctions migrates to engines in Phase 2 **without API contract change or UI rebuild**
- **Migration steps (per engine):**
  1. Phase 2: implement engine in Policy Center (or Compliance for sanctions)
  2. Add feature flag: `feature.vendor.use_doa_engine = false → true`
  3. Implement engine call in FN-05 (or FN-04 for sanctions) behind flag
  4. Run shadow mode: call engine in parallel, log diff vs inline result (no behavior change)
  5. When zero diff for 1 week → flip flag to true
  6. Remove inline placeholder code in next release
- **Rationale:** Engines introduce risk; shadow mode + feature flag de-risks the migration
- **Date locked:** 2026-05-29
- **Decided by:** Architect + DevOps

### LD-06: Vendor code format — locked permanent
- **Decision:** Format `V-{CC}-{TT}-{NNNNN}` with:
  - `V` literal prefix
  - `{CC}` = ISO-2 country code (2 chars)
  - `{TT}` = vendor type code (2 chars, from enum 11)
  - `{NNNNN}` = 5-digit running counter per (tenant, country, type) bucket
- **Examples:** `V-TH-MN-00001`, `V-TH-OT-00001`, `V-JP-TR-00012`
- **Rationale:** Format embeds country + type in code — useful for visual scan + sorting; 5 digits supports up to 99,999 vendors per (country, type) bucket which exceeds projected needs
- **Locked permanent:** code becomes external reference in PO/PV/AP — changing format is migration burden
- **Date locked:** 2026-05-29

### LD-07: tax_id immutable after KYC pass (IR-01)
- **Decision:** Once `vendor.kyc === 'passed'`, the tax_id field cannot be modified via any API
- **Rationale:** Audit + compliance — once an entity is verified by Compliance with a specific tax ID, changing it would invalidate the KYC. New tax ID → new vendor record
- **Bypass:** Admin can ONLY un-pass KYC first (`kyc=pending` via maintenance API — not exposed in standard UI), then edit tax_id, then re-run KYC review
- **Implementation:** FN-15 isImmutableTax + FN-02 guard + UI disable input
- **Date locked:** 2026-05-29 (matches BRD)

### LD-08: 6 states in lifecycle (no inactive/suspended/terminated)
- **Decision:** Lifecycle has exactly 6 reachable states: prospect / pending_kyc / pending_approval / active / blocked / blacklisted. No "inactive", "suspended", "terminated", "merged" states.
- **Rationale:**
  - "inactive" overlaps with "blocked" — both effectively prevent transactions
  - "suspended" implies time-limited which is unclear ownership
  - "terminated" overlaps with "blacklisted"
  - Simpler state machine = fewer edge cases
- **Use cases handled by existing states:**
  - "Retire vendor" → `blocked` with reason="retired"
  - "Permanent ban" → `blacklisted` (one-way)
- **Future:** Phase 3 may add "inactive" if retention policy requires distinction (e.g., dormant > 2 years auto-inactive)
- **Date locked:** 2026-05-29

### LD-09: Bank account encryption at rest (AES-256)
- **Decision:** `T_vendor_bank_account.acct` is encrypted at rest using PostgreSQL pgcrypto AES-256
- **Key management:** AWS KMS (or equivalent) for production; encryption key rotated annually
- **Performance impact:** ~10ms per row decrypt → acceptable given bank ops are not high-frequency
- **Rationale:** Restricted classification mandate + PCI DSS-adjacent best practice
- **Date locked:** 2026-05-29

### LD-10: Payment Terms — vendor stores code only, definition lives in Finance
- **Decision:** `T_vendor.term` is a FK to `Finance.payment_terms.code`. Vendor module does not own term definitions (discount %, baseline date, net days)
- **Rationale:**
  - Payment terms = Finance domain knowledge (CFO owns definitions)
  - Vendor module just references — separation of concerns
  - Changing a term (e.g., NET30 discount %) cascades to all vendors using it without per-vendor migration
- **Cross-domain dependency** documented in BRD §6.2 + 04_DB §4.3
- **Date locked:** 2026-05-29

### LD-11: Price List ownership boundary — Vendor Master is CONSUMER only ⭐ NEW v1.1
- **Decision:** All CRUD operations for vendor price list items live in **F-VENDOR-PRICE-LIST feature**. Vendor Master is a **read-only consumer** that displays a summary via API-16.
- **Boundary enforcement:**
  - **DB:** Vendor Master schema has **no `T_vendor_price_list` table** — data lives in F-VENDOR-PRICE-LIST's own schema
  - **API:** Vendor Master exposes only `GET /price-list-summary` (read) — no POST/PATCH/DELETE companion endpoints
  - **UI:** Tab 5 has **no edit/add/delete buttons** — all mutations require navigation to F-VENDOR-PRICE-LIST
  - **Logic:** FN-20 + ENG-PRICE-LIST-PROXY do not perform any mutations
- **Why this matters:**
  - Single Source of Truth — no risk of data divergence between Vendor Master and Price List
  - Separation of concerns — vendor team owns vendor identity, price list team owns commercial data
  - Permission model isolated — Price List has its own ACL (may differ from vendor:read/write)
- **Migration risk:** ❌ None — Phase 1 uses mock data inline; Phase 2 wires to real API without UI/contract change
- **Promoted from:** OQ-09 (partial — boundary decision)
- **Date locked:** 2026-05-31

### LD-12: Tab 5 field filtering at proxy layer ⭐ NEW v1.1
- **Decision:** API-16 / ENG-PRICE-LIST-PROXY returns only 5 fields per price list item: `code`, `name`, `price`, `unit`, `status`. Fields excluded: `category`, `minQty`, `validFrom`, `validTo`, `currency`, `notes`, `lastModifiedBy`, etc.
- **Rationale:**
  - **Performance:** ~60% payload reduction; faster Tab 5 render with 100+ items
  - **UX:** Procurement scans Tab 5 for quick context — full detail only when navigating to F-VENDOR-PRICE-LIST
  - **Forward compatibility:** F-VENDOR-PRICE-LIST may add fields without impacting Tab 5
  - **Validity rule:** `validFrom/validTo` is collapsed into `status` (active|expired) by F-VENDOR-PRICE-LIST — no need to re-derive at Vendor Master
- **Tradeoff:** Procurement cannot see min qty / validity range without clicking "ดู Price List เต็ม →" — acceptable per user UX intent
- **Implementation:** field whitelist applied in ENG-PRICE-LIST-PROXY (BR-X03)
- **Date locked:** 2026-05-31

## §7.2 Convention Deviations (CD)

### CD-01: Status-conditional Action Bar in View Drawer
- **Standard:** html-generator-v3 v3.6 Pattern C — View Drawer Tabbed = header + tabs + body + footer (actions in footer)
- **Deviation:** Inserted **status-conditional action bar** between header and tabs (bg off-white, right-aligned buttons)
- **Rationale:** Vendor has 4-6 conditional actions per status (Edit, Submit KYC, KYC Review, Approve step N, Reject, Block, Unblock, Blacklist) — too many for footer
- **Documented in:** BRD §14.6 Layout Deviation Log
- **Acceptable per:** "Iron rules ของ html-generator-v3 ไม่ถูก violate" — pattern customization is allowed when rationale is clear and documented
- **Mitigation:** Layout is consistent across all view drawers in Vendor Master (no inter-vendor inconsistency)

### CD-02: KYC tab removed from view drawer
- **Standard prototype (early):** had separate "KYC" tab in view drawer
- **Deviation:** Removed — KYC review is now triggered from action bar (KYC button visible to Compliance role only)
- **Rationale:** KYC review is workflow action, not data view. Modal-based action UX is cleaner than tab + button-inside-tab
- **Result:** 4 tabs (ภาพรวม / ธนาคาร & ติดต่อ / เอกสารแนบ / การอนุมัติ) instead of 5

### CD-03: No KPI scorecards on landing
- **Standard:** Iron Rule #8 (Stats/KPI Row Optional)
- **Deviation:** Vendor List has no KPI scorecards on landing page
- **Rationale:** Per user explicit request — scorecards add visual weight without operational value for this feature
- **Acceptable:** Rule #8 is optional, deviation is towards minimalism (not adding non-standard elements)

### CD-04: tenant_id naming convention
- **Standard convention (knowledge/conventions.md):** snake_case for DB columns
- **No deviation:** all DB columns use snake_case (`tenant_id`, `tax_id`, `created_by` etc) — listed here for completeness

### CD-05: View Drawer with 5 tabs (instead of standard 3-4) ⭐ NEW v1.1
- **Standard:** Pattern C — View Drawer Tabbed typically supports 3-4 tabs that fit without overflow
- **Deviation:** 5 tabs (ภาพรวม · ธนาคาร & ติดต่อ · เอกสารแนบ · การอนุมัติ · **สินค้า/บริการ**)
- **Rationale:** Tab 5 (Price List read-only embed) added per user request — gives Procurement quick context (what does this vendor sell?) without needing to navigate to a separate feature
- **Acceptable per:** v3.6 design system has built-in `.drawer-tabs { overflow-x: auto; scrollbar-width: none }` — tabs scroll horizontally when total width exceeds drawer width; pattern is built to handle this
- **Total label width:** ~697px > 508px drawer body width — scroll behavior active (tested in browser)
- **Documented in:** BRD §14.6 row "View Drawer — Tab count" + html-generator-v3 v3.6 drawer-tabs CSS

### CD-06: Tab 5 has no edit/add/delete UI ⭐ NEW v1.1
- **Standard:** View drawer tabs typically have at minimum a "Refresh" or "More actions" button
- **Deviation:** Tab 5 has **zero mutation UI** — no buttons except navigation ("ดู Price List เต็ม →")
- **Rationale:** Data ownership boundary (LD-11) — Vendor Master is consumer, not editor, of price list data
- **Risk mitigation:** User might wonder where to edit — addressed by clear navigation button + explicit info-box note "ข้อมูลจาก Vendor Price List · view-only · แก้ไขผ่าน feature Price List"

## §7.3 Open Questions Promoted from 00_OVERVIEW

| OQ # | Status | Promoted to LD | Notes |
|---|---|---|---|
| OQ-01 (DOA rule actual) | **Promoted** | LD-03 | Phase 1 placeholder + Phase 2 engine wire |
| OQ-02 (Classification engine format) | **Promoted** | LD-04 | Same pattern as LD-03 |
| OQ-03 (Sanctions API source) | Open | — | Awaiting Compliance team selection (Refinitiv vs Dow Jones vs in-house) |
| OQ-04 (KYC expiry policy) | Open | — | Default: yearly review; Compliance to confirm |
| OQ-05 (Rename pending_kyc label?) | Open | — | UX + BA decision; not blocking Phase 1 |
| OQ-06 (Bank acct length per bank) | Open | — | Phase 1.5 enrichment with Bank master config |
| OQ-07 (PDPA delete flow detail) | Open | — | Phase 2 — Legal + Compliance scope |
| OQ-08 (Vendor migration format) | Open | — | Pilot client coordination (COE, WKN) |
| **OQ-09 (Price List API contract) ⭐ NEW v1.1** | **Partially promoted** | **LD-11 (boundary), LD-12 (field filtering)** | **Remaining open:** endpoint shape details, auth model, cache TTL config, paging strategy for vendors with > 100 items, invalidation event format |

**Remaining open:** 7 OQs (3 deferred to Phase 2+, 3 awaiting input from external teams, 1 partially resolved via LD-11 + LD-12)

## §7.4 Architecture Tradeoffs Acknowledged

### Tradeoff 1: JSONB approval_chain vs separate table
- **Chose:** JSONB column in T_vendor
- **Pro:** Simpler reads, atomic with vendor updates, fits 1:1 ownership
- **Con:** Complex queries for "approval queue" require GIN index + JSONB operators
- **Mitigation:** Phase 1 has approval-queue scenarios under test; query plan reviewed by DBA before prod

### Tradeoff 2: Hardcoded mask (Phase 1) vs engine call (Phase 2)
- **Chose:** Hardcoded in Phase 1
- **Pro:** Ships before Policy Center wave; lower coupling
- **Con:** Mask logic duplicated across features (each feature implements its own mask)
- **Mitigation:** LD-05 migration plan (shadow mode + feature flag)

### Tradeoff 3: Optimistic locking (LD-01)
- **Chose:** Optimistic
- **Pro:** No DB row contention; better read-heavy performance
- **Con:** Users see occasional STALE_VERSION errors
- **Mitigation:** UI surfaces clear error + refresh button

### Tradeoff 4: WORM as DB grant + trigger (not separate audit DB)
- **Chose:** Same PostgreSQL, INSERT-only grant + trigger
- **Pro:** Atomic with mutations (transaction guarantees), simpler ops, lower cost
- **Con:** Privileged DB user could theoretically bypass (mitigated by role separation + monitoring)
- **Mitigation:** DB role for app has only INSERT on audit; superuser access logged + alerted

### Tradeoff 5: Phase 1 includes 14 seed vendors (HTML prototype)
- **Decision:** Seed data lives in HTML prototype only; production starts empty + pilot client imports from Excel (OQ-08)
- **Implication:** First demo/UAT for new client requires data import OR manual entry
- **Acceptable:** Pilot lift; not affecting Phase 1 functional scope

---

**Locked Decision Count:** 12 LDs · 6 CDs · 9 OQs (2 promoted to LD in v1.0 + 1 partially promoted in v1.1, 6 remaining open)
**Status:** Ready for Phase 1 development handoff (v1.1 includes Tab 5 cross-feature integration)
