# 06_TESTS — F-VENDOR-MASTER-001 Vendor Master

> Audience: QA + Dev (definition of done)
> Source: BRD §7 (User Stories with AC) + 05_RULES §5.5 (Edge Cases)

## §6.1 Acceptance Criteria (AC)

### AC-01: List vendors with filters
**Given** authenticated user with role ∈ all 6
**When** GET /api/v1/vendors?type=MN&status=active
**Then** response 200 with `records[]` filtered to type=MN AND status=active
**And** sensitive fields masked per role (tax_id, bank.acct)
**And** pagination respected (default 20/page)

### AC-02: Create vendor — happy path
**Given** Procurement Officer authenticated, valid input
**When** POST /api/v1/vendors with valid body + Idempotency-Key
**Then** response 201 with `{ code: "V-TH-MN-00003", status: "prospect", version: 1 }`
**And** audit entry `created` inserted
**And** repeating same Idempotency-Key returns same response (no duplicate)

### AC-03: Create vendor — duplicate tax_id
**Given** vendor V001 with tax_id=0105551234567 in TH already exists
**When** POST /api/v1/vendors with tax_id=0105551234567, country=TH
**Then** response 409 with code `DUPLICATE_TAX_ID`
**And** no record inserted
**And** no audit entry

### AC-04: Create OT vendor without tax_id
**Given** type=OT
**When** POST /api/v1/vendors with tax_id=null, rest valid
**Then** response 201 (tax_id optional for OT)
**And** UI displays "ยกเว้น" for tax field

### AC-05: Submit for KYC
**Given** vendor V015 status=prospect
**When** POST /api/v1/vendors/V015/submit-kyc
**Then** response 200, status=pending_kyc
**And** audit `submitted_for_kyc` entry by actor

### AC-06: KYC review — passed
**Given** vendor V015 status=pending_kyc, role=Compliance
**When** POST /api/v1/vendors/V015/kyc-review with `{ result:"passed", sanctions_hit:false }`
**Then** response 200, kyc=passed, kycAt populated
**And** subsequent PATCH attempting to modify tax_id returns 422 `IMMUTABLE_TAX_ID` (IR-01)

### AC-07: KYC review — sanctions hit (auto-block)
**Given** vendor V020 status=pending_kyc
**When** POST kyc-review with `{ result:"passed", sanctions_hit:true }`
**Then** response 200, kyc=failed, status=blocked, block="พบรายชื่อต้องห้าม (sanctions hit)"
**And** audit `sanctions_hit_auto_block` (variant=danger)

### AC-08: Submit for approval — non-OT
**Given** vendor V015 type=MN, kyc=passed, ≥1 contact valid, ≥1 verified bank, creditLimit=2,000,000
**When** POST /submit-approval
**Then** response 200, status=pending_approval
**And** approvalChain built by ENG-DOA-CHAIN: `[{seq:1, role:"procurement_manager", status:"pending"}]` (creditLimit > 1M but ≤ 5M)

### AC-09: Submit for approval — OT auto-approve
**Given** vendor V021 type=OT, kyc=passed, ≥1 contact valid
**When** POST /submit-approval
**Then** response 200, status=**active** (skip pending_approval)
**And** approvedBy="ระบบ (auto)", approvedAt populated
**And** audit `ot_auto_approved`

### AC-10: Submit for approval — KYC not passed
**Given** vendor V022 kyc=pending or failed
**When** POST /submit-approval
**Then** response 422 `KYC_NOT_PASSED`
**And** status unchanged

### AC-11: Approve step 1 (single-step chain)
**Given** vendor V023 status=pending_approval, chain=`[{seq:1, role:"procurement_manager", status:"pending"}]`, actorRole=Procurement Manager, actorUid ≠ createdBy
**When** POST /approve with `{ comment:"OK" }`
**Then** response 200, status=**active**, chain[0].status=approved, approvedBy=actor

### AC-12: Approve step 1, await step 2 (multi-step chain)
**Given** vendor V024 status=pending_approval, chain=`[{seq:1, role:"procurement_manager", status:"pending"}, {seq:2, role:"procurement_director", status:"pending"}]`, actor=Manager
**When** POST /approve
**Then** response 200, status=**still pending_approval**, chain[0].status=approved, chain[1].status=pending
**And** `nextStep` indicates Director needed

### AC-13: Approve — SoD violation
**Given** vendor V025, createdBy=manop, current step role=Manager, actor=manop (same as creator)
**When** POST /approve
**Then** response 422 `SOD_VIOLATION`
**And** chain unchanged

### AC-14: Approve — wrong approver
**Given** chain current step role=Director, actor=Officer
**When** POST /approve
**Then** response 422 `WRONG_APPROVER`

### AC-15: Reject mid-chain
**Given** vendor V026, chain step 1 approved, step 2 pending, actor=Director
**When** POST /reject with `{ reason:"ข้อมูลธนาคารไม่ครบ" }`
**Then** response 200, status=**pending_kyc**, approvalChain=`[]` (cleared)
**And** audit `rejected — ข้อมูลธนาคารไม่ครบ`

### AC-16: Verify bank — Finance
**Given** vendor V027 has bank index 0 with verified=false, actor=Finance, actorUid ≠ createdBy
**When** POST /banks/0/verify
**Then** response 200, banks[0].verified=true, verified_by, verified_at populated
**And** audit `bank_verified — <masked_acct>`

### AC-17: Verify bank — SoD violation
**Given** Finance user IS the creator
**When** POST /banks/0/verify
**Then** response 422 `SOD_VIOLATION`

### AC-18: Block active vendor
**Given** vendor V028 status=active
**When** POST /block with `{ reason:"ระงับชั่วคราว — รอตรวจสอบ" }`
**Then** response 200, status=blocked, block reason populated
**And** audit `blocked — ระงับชั่วคราว — รอตรวจสอบ`

### AC-19: Unblock
**Given** vendor V028 status=blocked
**When** POST /unblock with `{ reason:"ผ่านการตรวจสอบแล้ว" }`
**Then** response 200, status=active, block=''

### AC-20: Blacklist — Director only
**Given** actor=Director, vendor=active
**When** POST /blacklist with `{ reason:"พบประวัติฉ้อโกง" }`
**Then** response 200, status=blacklisted (terminal)
**And** subsequent POST /unblock returns 409 `TERMINAL_STATE`

### AC-21: Blacklist — wrong role
**Given** actor=Officer
**When** POST /blacklist
**Then** response 403 `BLACKLIST_REQUIRES_DIRECTOR`

### AC-22: Masking — tax_id per role
**Given** vendor V001 tax_id=0105551234567
**When** GET /vendors/V001 with role=Procurement Officer
**Then** response `tax: "0105••••••67"` (masked)
**When** GET /vendors/V001 with role=Finance
**Then** response `tax: "0105551234567"` (full)

### AC-23: Masking — bank.acct (Restricted)
**Given** vendor V001 bank[0].acct=0123456789
**When** GET with role=Procurement (any of 3 levels)
**Then** `banks[0].acct: "0123••••89"` (masked)
**When** GET with role=Compliance
**Then** still masked (Restricted, only Finance/Admin see full)
**When** GET with role=Finance
**Then** full value

### AC-24: Optimistic locking
**Given** vendor V001 version=5
**When** PATCH /vendors/V001 with If-Match: 4 (stale)
**Then** response 409 `STALE_VERSION` with current version in body

### AC-25: WORM audit immutability
**Given** any audit entry inserted
**When** DBA attempts UPDATE or DELETE on T_vendor_audit
**Then** PostgreSQL raises exception `WORM_VIOLATION` (DB trigger)
**And** no rows changed

### AC-26: List "approval queue for me"
**Given** authenticated as Procurement Manager
**When** GET /vendors?my_approval=true (or filter by approval_chain @> '[{"role":"procurement_manager","status":"pending"}]')
**Then** response 200 with only vendors that have current pending step assigned to Manager role

### AC-27: Edit blocked — disallowed
**Given** vendor V029 status=blocked
**When** PATCH /vendors/V029
**Then** response 403 (edit allowed only for {prospect, pending_kyc, active})

### AC-28: View Price List Tab 5 — vendor with items ⭐ NEW v1.1
**Given** vendor V001 has price list with 5 items in F-VENDOR-PRICE-LIST (Phase 1: mock data inline; Phase 2: real API)
**When** user opens view drawer + clicks tab "สินค้า/บริการ"
**Then** GET /vendors/V001/price-list-summary returns 200 with `items[5]`, `total=5`, `active_count=5`
**And** UI renders compact table with 5 rows, each showing name + code + price + unit + green status dot
**And** summary box displays "5 รายการ · อัพเดต DD MMM YYYY"
**And** **no edit/add/delete buttons** visible in this tab (BR-X02)
**And** footer button "ดู Price List เต็ม →" navigates to F-VENDOR-PRICE-LIST when clicked

### AC-29: View Price List Tab 5 — vendor without items ⭐ NEW v1.1
**Given** vendor V007 (Employee type) has no price list in F-VENDOR-PRICE-LIST
**When** user opens view drawer + clicks tab "สินค้า/บริการ"
**Then** API-16 returns 200 with `items=[]`, `total=0`
**And** UI renders empty state with icon `package-x` + text "ยังไม่มี Price List สำหรับคู่ค้านี้"
**And** centered button "ไปที่ Price List feature →" navigates to F-VENDOR-PRICE-LIST

### AC-30: View Price List Tab 5 — vendor with expired items ⭐ NEW v1.1
**Given** vendor V003 has 4 items in Price List (3 active, 1 expired)
**When** user clicks tab "สินค้า/บริการ"
**Then** API-16 returns `active_count=3, expired_count=1`
**And** UI summary shows "(3 active · 1 expired)"
**And** the expired row has `class="is-inactive"` → opacity 0.55 + strikethrough on name + brown status dot
**And** active rows render normally with green status dot

### AC-31: Tab 5 — F-VENDOR-PRICE-LIST API unavailable ⭐ NEW v1.1
**Given** F-VENDOR-PRICE-LIST service is down or returns 5xx
**When** user clicks tab "สินค้า/บริการ"
**Then** API-16 returns 502 Bad Gateway
**And** UI displays fallback message "ไม่สามารถดึง Price List ได้ — ลองใหม่ภายหลัง"
**And** other tabs (overview, bank, attachments, approval) **remain functional** (BR-X05 resilience)
**And** Tab 5 has a retry button

## §6.2 Test Case Inventory

| TC ID | Type | Maps to AC | Edge Case | Priority |
|---|---|---|---|---|
| TC-AC-01 to TC-AC-27 | Functional | AC-01 to AC-27 | — | High |
| **TC-AC-28 ⭐ v1.1** | Functional | AC-28 Tab 5 with items | — | High |
| **TC-AC-29 ⭐ v1.1** | Functional | AC-29 Tab 5 empty state | — | Medium |
| **TC-AC-30 ⭐ v1.1** | Functional | AC-30 Tab 5 expired items | — | Medium |
| **TC-AC-31 ⭐ v1.1** | Resilience | AC-31 Price List API down | — | High |
| TC-EC-01 | Negative | AC-03 | EC-01 duplicate tax_id | High |
| TC-EC-02 | Positive | AC-04 | EC-02 OT no-tax | High |
| TC-EC-03 | Negative | AC-10 | EC-03 KYC not passed | High |
| TC-EC-04 | Negative | (extends AC-08) | EC-04 missing contact | High |
| TC-EC-05 | Negative | (extends AC-08) | EC-05 missing verified bank | High |
| TC-EC-06 | Negative | AC-13 | EC-06 SoD violation | High |
| TC-EC-07 | Negative | AC-14 | EC-07 wrong approver | High |
| TC-EC-08 | Negative | AC-07 | EC-08 sanctions hit | Critical |
| TC-EC-09 | Negative | (related AC-06) | EC-09 IR-01 immutable | High |
| TC-EC-10 | Negative | AC-15 | EC-10 reject clears chain | High |
| TC-EC-11 | Positive | AC-18 | EC-11 soft-block w/ hasTxn | High |
| TC-EC-12 | Negative | AC-20 | EC-12 terminal blacklist | High |
| TC-EC-13 | Positive | — | EC-13 last verified bank removed | Medium |
| TC-EC-14 | Functional | — | EC-14 non-TH tax format | Low (Phase 2) |
| TC-EC-15 | Concurrency | — | CA — concurrent approve | High |
| TC-EC-16 | Boundary | — | EM — empty sub-arrays | Medium |
| TC-EC-17 | Resilience | — | DI — network drop + retry | High |
| TC-EC-18 | Concurrency | AC-24 | ST — version conflict | High |
| TC-EC-19 | Security | — | PM — role lowered mid-session | High |
| TC-EC-20 | Security | — | EN — XSS prevention | Medium |
| TC-PERF-01 | Performance | — | list 10k vendors p95 < 300ms | High |
| TC-PERF-02 | Performance | — | detail with sub-arrays p95 < 100ms | Medium |
| TC-PERF-03 | Performance | — | approval queue query p95 < 200ms | High |
| TC-SEC-01 | Security | AC-22, AC-23 | masking enforcement at API | Critical |
| TC-SEC-02 | Security | — | encryption at rest on bank.acct | Critical |
| TC-SEC-03 | Security | AC-25 | WORM audit trigger | Critical |

**Total: 27 functional AC tests + 20 edge case tests + 3 performance + 3 security = 53 test cases**

⭐ **v1.1 addition:** +4 AC tests for Tab 5 (AC-28 to AC-31) → **31 AC tests + 20 EC + 3 perf + 3 security = 57 test cases**

## §6.3 Test Data Setup

### Required test data (seed)

- **3 vendors** at each lifecycle state (3 × 6 = 18 seed vendors, sharing the 14 seeds from HTML prototype + 4 supplementary)
- **6 user accounts**, one per role: somsri (Officer), manop (Manager), wichai (Director), napha (Finance), kamol (Compliance), admin
- **1 tenant** ("CUBE NATIVE") for primary tests; **1 secondary tenant** for cross-tenant isolation tests
- **Sanctions test list:** at least 1 vendor name matching mock sanctions feed for TC-EC-08

### Roles for testing

```
somsri  → procurement_officer  → creates vendors, submits, approves step 1 (small)
manop   → procurement_manager  → approves step 1-2
wichai  → procurement_director → approves any (override), blacklists
napha   → finance              → verifies bank
kamol   → compliance           → reviews KYC
admin   → admin                → bypass for setup/teardown
```

### Test environment

| Env | Purpose | Reset |
|---|---|---|
| Local dev | unit + integration | per-test transaction rollback |
| CI staging | E2E API tests | nightly DB seed reset |
| UAT | Manual QA + UAT | per-sprint reset to v1.0 baseline |
| Production | smoke test only (no destructive) | n/a |

## §6.4 Definition of Done (DoD)

### Code
- [ ] All 15 APIs implemented (API-01 to API-15)
- [ ] **API-16 implemented** (Price List Summary proxy) ⭐ v1.1 — Phase 1 mock, Phase 2 wire to F-VENDOR-PRICE-LIST
- [ ] All 19 Functions implemented (FN-01 to FN-19)
- [ ] **FN-20 fetchPriceListSummary implemented** ⭐ v1.1
- [ ] All 4 Engines integrated (ENG-DOA-CHAIN placeholder + 3 others)
- [ ] **ENG-PRICE-LIST-PROXY consumer wired (Phase 2)** ⭐ v1.1
- [ ] All 6 DB tables created with constraints + indexes
- [ ] WORM trigger on T_vendor_audit (UPDATE/DELETE → exception)
- [ ] AES-256 encryption configured on bank.acct
- [ ] API gateway masking middleware enforces classification per role
- [ ] Idempotency key middleware on POST endpoints
- [ ] Optimistic locking via If-Match header on PATCH
- [ ] **Tab 5 UI has NO edit/add/delete buttons (BR-X02)** ⭐ v1.1

### Documentation
- [ ] OpenAPI spec generated from code, matches 02_API §2.2
- [ ] DB schema docs match 04_DB §4.2
- [ ] README per service with deploy instructions
- [ ] Engine registration documented (for Phase 2 wire-up)

### QA
- [ ] All 53 test cases pass (27 AC + 20 EC + 3 perf + 3 security)
- [ ] Code coverage ≥ 80% on FN layer (target 95% on critical paths: FN-04, FN-05, FN-07)
- [ ] E2E smoke run on UAT before production deploy
- [ ] 1 pilot client (COE) UAT sign-off

### Security
- [ ] Threat model review by security team
- [ ] Penetration test scoped to vendor APIs (focus: masking bypass, SoD bypass, audit tampering)
- [ ] All 78 Security Controls (P2 preset) verified
- [ ] PII inventory updated with vendor fields

### Performance
- [ ] List API p95 < 300ms with 10k vendors (load test)
- [ ] Detail API p95 < 100ms
- [ ] Approval queue query p95 < 200ms
- [ ] No N+1 query issues (verified by query log review)

### Audit Trail
- [ ] Every mutation API verified to write WORM audit entry
- [ ] Audit retention policy configured (7 years)
- [ ] Audit query API tested (API-14)

### Acceptance
- [ ] Stakeholder sign-off: CPO + CFO + Compliance Lead + Internal Audit
- [ ] Pilot client (COE) signs off on operational fit
- [ ] All 8 Open Questions (BRD §15) resolved OR explicitly deferred to Phase 2
