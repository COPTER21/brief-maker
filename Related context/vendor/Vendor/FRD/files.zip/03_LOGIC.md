# 03_LOGIC — F-VENDOR-MASTER-001 Vendor Master

> Audience: BE dev (business logic layer) + Architect (Engine candidates)
> Scope: All non-HTTP logic — pure functions, state transitions, calculations, validations, integrations
> **R8 Anchor:** every mutation API in 02_API §2.4 traces to a function/engine here

## §3.1 Functions (Scope-Local)

> Logic used only in this feature — NOT registered as CUBIC engine

### F-VENDOR-MASTER-001-FN-01: `createVendor`
- **Purpose:** สร้าง vendor record ใหม่ (status=prospect, version=1)
- **Input:** `{ name, type, country, tax?, vat?, companyReg?, currency, term, wht?, creditLimit?, contacts[], addresses[], banks[], attachments[], createdBy }`
- **Output:** `Vendor | ValidationError[]`
- **Invoked by:** API-03 POST /vendors
- **Calls:** FN-13 genVendorCode, FN-14 validateVendorInput
- **Side effects:** INSERT T_vendor + T_contact + T_address + T_bank_account + T_attachment + WORM audit
- **Iron rule check:** ✅ no HTTP terms

### F-VENDOR-MASTER-001-FN-02: `updateVendor`
- **Purpose:** Update vendor fields with IR-01 enforcement
- **Input:** `{ id, version, patch: Partial<Vendor> }`
- **Output:** `Vendor | { conflict: "STALE_VERSION" | "IMMUTABLE_TAX_ID" | ... }`
- **Invoked by:** API-04 PATCH /vendors/{id}
- **Calls:** FN-14 validateVendorInput, FN-15 isImmutableTax
- **Side effects:** UPDATE T_vendor (version++) + WORM audit
- **Iron rule check:** ✅

### F-VENDOR-MASTER-001-FN-03: `submitForKyc`
- **Purpose:** Transition prospect → pending_kyc
- **Input:** `{ vendorId, actorUid }`
- **Output:** `Vendor | { error: "INVALID_TRANSITION" }`
- **Invoked by:** API-05 POST /submit-kyc
- **Side effects:** UPDATE T_vendor.status + WORM audit
- **Guard:** status must be `prospect`

### F-VENDOR-MASTER-001-FN-04: `reviewKyc`
- **Purpose:** Compliance reviews vendor KYC; sets kyc + handles sanctions hit
- **Input:** `{ vendorId, result: 'passed'|'failed', sanctionsHit: bool, notes, actorUid }`
- **Output:** `Vendor`
- **Invoked by:** API-06 POST /kyc-review
- **Calls:** **ENG-SANCTIONS** (if not pre-checked)
- **Side effects:**
  - if sanctionsHit → status=blocked, block="sanctions hit", kyc=failed
  - else if result=passed → kyc=passed, kycAt=now, **lock tax_id (IR-01)**
  - else → kyc=failed
  - WORM audit
- **Iron rule check:** ✅

### F-VENDOR-MASTER-001-FN-05: `submitForApproval`
- **Purpose:** Transition pending_kyc → pending_approval; build DOA chain
- **Input:** `{ vendorId, actorUid }`
- **Output:** `Vendor | { error: 'KYC_NOT_PASSED'|'NOT_READY' }`
- **Invoked by:** API-07 POST /submit-approval
- **Calls:** **ENG-DOA-CHAIN** to resolve chain, FN-16 hasValidContact, FN-17 paidVendorNeedsBank
- **Side effects:**
  - if OT type → delegate to FN-06 (auto-approve)
  - else → UPDATE T_vendor.status=pending_approval, INSERT approvalChain JSON
  - WORM audit
- **Guards:** kyc==='passed' AND ≥1 valid contact AND (OT OR ≥1 verified bank)

### F-VENDOR-MASTER-001-FN-06: `autoApproveOneTime`
- **Purpose:** OT vendor — skip approval chain, go directly active
- **Input:** `{ vendorId, actorUid }`
- **Output:** `Vendor`
- **Invoked by:** FN-05 (when type='OT')
- **Side effects:** status=active, approvedBy='ระบบ (auto)', approvedAt=now, WORM audit

### F-VENDOR-MASTER-001-FN-07: `approveCurrentStep`
- **Purpose:** Approve current pending step in chain; advance or complete
- **Input:** `{ vendorId, actorUid, actorRole, comment? }`
- **Output:** `Vendor | { error: 'KYC_NOT_PASSED'|'SOD_VIOLATION'|'WRONG_APPROVER'|'NOT_READY' }`
- **Invoked by:** API-08 POST /approve
- **Calls:** FN-18 canApproveCurrent, FN-19 chainDone
- **Side effects:**
  - mark current step `status='approved'`, set approver+at
  - if chainDone → status=active, approvedBy=last, approvedAt=now
  - else → status stays pending_approval, advance to next pending step
  - WORM audit (step + chain_complete if applicable)
- **Iron rule check:** ✅

### F-VENDOR-MASTER-001-FN-08: `rejectApproval`
- **Purpose:** Reject in approval; back to pending_kyc; clear chain
- **Input:** `{ vendorId, reason, actorUid }`
- **Output:** `Vendor | { error: 'REASON_REQUIRED' }`
- **Invoked by:** API-09 POST /reject
- **Guard:** reason ≥ 5 chars, current step approver match (or override)
- **Side effects:** status=pending_kyc, approvalChain=[], WORM audit

### F-VENDOR-MASTER-001-FN-09: `verifyBankAccount`
- **Purpose:** Finance verifies a bank account
- **Input:** `{ vendorId, bankIdx, actorUid }`
- **Output:** `Vendor`
- **Invoked by:** API-10 POST /banks/{idx}/verify
- **Guard:** role=Finance/Admin AND actorUid ≠ createdBy (SoD-03)
- **Side effects:** banks[idx].verified=true, verified_at=now, WORM audit

### F-VENDOR-MASTER-001-FN-10: `blockVendor`
- **Purpose:** Block active vendor (soft-block, retain vendor_id)
- **Input:** `{ vendorId, reason, actorUid }`
- **Output:** `Vendor | { error: 'REASON_REQUIRED'|'INVALID_TRANSITION' }`
- **Invoked by:** API-11 POST /block
- **Guard:** status=='active', reason non-empty
- **Side effects:** status=blocked, block=reason, WORM audit

### F-VENDOR-MASTER-001-FN-11: `unblockVendor`
- **Purpose:** Unblock back to active
- **Input:** `{ vendorId, reason, actorUid }`
- **Output:** `Vendor`
- **Invoked by:** API-12 POST /unblock
- **Guard:** status=='blocked', reason non-empty
- **Side effects:** status=active, block='', WORM audit

### F-VENDOR-MASTER-001-FN-12: `blacklistVendor`
- **Purpose:** Terminal blacklist (one-way)
- **Input:** `{ vendorId, reason, actorUid, actorRole }`
- **Output:** `Vendor | { error: 'BLACKLIST_REQUIRES_DIRECTOR' }`
- **Invoked by:** API-13 POST /blacklist
- **Guard:** role ∈ {procurement_director, admin}
- **Side effects:** status=blacklisted, block=reason, WORM audit

### F-VENDOR-MASTER-001-FN-13: `genVendorCode`
- **Purpose:** Generate next vendor code per country+type running counter
- **Input:** `{ country: ISO-2, type: enum }`
- **Output:** `string` (format `V-{CC}-{TT}-{NNNNN}`)
- **Invoked by:** FN-01 createVendor, API-15 GET /_next-code
- **Pure function** — reads max running counter from DB (`SELECT MAX(N) WHERE prefix=...`)
- **Race condition:** wrap in INSERT with unique constraint on code; on collision retry with N+1

### F-VENDOR-MASTER-001-FN-14: `validateVendorInput`
- **Purpose:** Validate vendor fields (per-field + cross-field)
- **Input:** `Vendor (full or partial)`
- **Output:** `ValidationError[] | []`
- **Checks:**
  - name required, ≤255
  - tax format (13 digits Thai checksum, or per-country regex from Country master)
  - tax unique per country (DB UQ)
  - bank acct 10-15 digits
  - contact email valid format
  - currency ∈ Currency master
  - term ∈ Payment Terms master (Finance domain)

### F-VENDOR-MASTER-001-FN-15: `isImmutableTax`
- **Purpose:** Check IR-01 — is tax_id locked?
- **Input:** `Vendor`
- **Output:** `boolean`
- **Logic:** `return vendor.kyc === 'passed'`

### F-VENDOR-MASTER-001-FN-16: `hasValidContact`
- **Purpose:** ≥1 contact with email AND phone
- **Input:** `Vendor`
- **Output:** `boolean`

### F-VENDOR-MASTER-001-FN-17: `paidVendorNeedsBank`
- **Purpose:** non-OT vendor requires ≥1 verified bank
- **Input:** `Vendor`
- **Output:** `boolean` — `vendor.type !== 'OT'`

### F-VENDOR-MASTER-001-FN-18: `canApproveCurrent`
- **Purpose:** Check if actor can approve the current pending step
- **Input:** `{ vendor, actorRole }`
- **Output:** `boolean`
- **Logic:**
  ```
  step = currentStep(vendor.approvalChain)
  if !step → false
  return actorRole === step.role OR actorRole === 'procurement_director' OR actorRole === 'admin'
  ```
- **Used by:** UI button visibility (canApproveCurrent in HTML), FN-07 guard

### F-VENDOR-MASTER-001-FN-19: `chainDone`
- **Purpose:** Check if all steps in chain are approved
- **Input:** `Vendor`
- **Output:** `boolean`
- **Logic:** `chain.length > 0 && chain.every(s => s.status === 'approved')`

### F-VENDOR-MASTER-001-FN-20: `fetchPriceListSummary` ⭐ NEW v1.1
- **Purpose:** Fetch read-only Price List summary from F-VENDOR-PRICE-LIST + field-filter for Tab 5 + cache
- **Input:** `{ vendorId, tenantId, limit?: number }`
- **Output:** `{ items: PriceListItem[], total, active_count, expired_count, updated_at, source }` or `{ items: [], total: 0 }` if empty
- **Invoked by:** API-16 GET /vendors/{id}/price-list-summary
- **Calls:** **ENG-PRICE-LIST-PROXY** (Phase 2 — calls F-VENDOR-PRICE-LIST internal API)
- **Side effects:** None (read-only) · writes to Redis cache (5-min TTL)
- **Logic:**
  ```
  1. Check Redis cache: key = pls:{tenantId}:{vendorId}
     - If hit and not stale → return cached
  2. Call ENG-PRICE-LIST-PROXY.get(tenantId, vendorId, limit)
     - On error/timeout → return empty + log + propagate 502 to API layer
  3. Field-strip response (cut category, minQty, validFrom, validTo) — BR-X01
     - Keep: code, name, price, unit, status
  4. Write to Redis cache (TTL 5 min)
  5. Return summary
  ```
- **Phase 1:** Implemented as inline `PRICE_LIST_BY_VENDOR` mock data in HTML (no API call, no cache); Phase 2 replaces with full pipeline
- **Permission:** All 6 roles can call (Price List is not Confidential)
- **Iron rule check:** ✅ no HTTP terms, pure logic with infrastructure dependencies abstracted

---

## §3.2 Engines (Reusable / CUBIC-Registered)

> Cross-feature use OR complex calculation → register CUBIC Registry

### ENG-DOA-CHAIN: `doa-chain-resolver` [NEW — Phase 2 implementation]
- **id:** (assigned at Policy Center registration)
- **code:** `doa-chain-resolver`
- **name:** DOA Approval Chain Resolver
- **category:** policy-engine
- **module:** Policy Center
- **input schema:**
  ```json
  {
    "entityType": "vendor",
    "entityId": "string",
    "attributes": { "creditLimit": number, "type": string, "country": string, ... }
  }
  ```
- **output schema:**
  ```json
  {
    "chain": [
      { "seq": 1, "role": "procurement_manager", "label": "ผู้จัดการจัดซื้อ", "required": true }
    ]
  }
  ```
- **logic outline:**
  1. Lookup DOA policy rule by entityType + attributes
  2. Evaluate condition tree (e.g., creditLimit threshold)
  3. Return ordered approver chain
- **Used by features:** F-VENDOR-MASTER-001 (Phase 1: placeholder rule inline; Phase 2: switch to this engine)
- **Phase 1 placeholder (inline in feature):**
  ```js
  function resolveApprovalChain(r) {
    if (r.type === 'OT') return [];
    const cl = +r.creditLimit || 0;
    if (cl > 5000000) return [{role:'procurement_manager'}, {role:'procurement_director'}];
    if (cl > 1000000) return [{role:'procurement_manager'}];
    return [{role:'procurement_officer'}];
  }
  ```
- **Iron rule check:** ✅ pure, no HTTP, reusable
- **Migration plan:** Phase 1 inline → Phase 2 wire to engine (no UI change, only logic layer swap)

### ENG-SANCTIONS: `sanctions-screening` [NEW]
- **code:** `sanctions-screening`
- **name:** Sanctions Screening Engine
- **category:** compliance-check
- **module:** Compliance
- **input schema:**
  ```json
  { "name": "string", "tax_id": "string", "country": "ISO-2" }
  ```
- **output schema:**
  ```json
  { "hit": boolean, "matches": [{ "list": "OFAC|UN|EU", "name": "...", "confidence": 0.95 }], "checkedAt": "..." }
  ```
- **logic outline:**
  1. Normalize input (uppercase, remove suffixes บจก./Ltd./ฯลฯ)
  2. Call external sanctions API (OFAC/UN/EU — source TBD per OQ-03)
  3. Fuzzy match name + exact match tax_id
  4. Return hit/no-hit with details
- **Used by features:** F-VENDOR-MASTER-001 (KYC review), F-CUSTOMER-MASTER (future)
- **Phase 1:** stub (always returns `{ hit: false }` unless test flag set in UI)
- **Iron rule check:** ✅

### ENG-DATA-CLASSIFICATION: `data-classification-mask` [NEW — Phase 2]
- **code:** `data-classification-mask`
- **name:** Data Classification Masking Engine
- **category:** security
- **module:** Policy Center
- **input schema:**
  ```json
  {
    "record": object,
    "schema": { "fieldName": { "classification": "Public|Internal|Confidential|Restricted", "pii_flag": bool } },
    "actorRole": "string"
  }
  ```
- **output schema:** `record with masked fields per role`
- **logic outline:**
  1. For each field in record, look up classification from schema
  2. Look up role-to-classification visibility matrix
  3. If field not visible → mask (pattern depends on field type)
- **Phase 1 placeholder (hardcoded in vendor feature):**
  - `maskTax(tax)` — 4 prefix + dots + 2 suffix
  - `maskAcct(acct)` — 3 prefix + dots + 2 suffix
  - role check `canSeeTax()`, `canSeeBankNo()`
- **Used by features:** F-VENDOR-MASTER-001, all future features touching Confidential/Restricted
- **Iron rule check:** ✅
- **Migration plan:** Phase 2 — replace hardcoded with engine call

### ENG-CODE-GEN: `running-code-generator` [REUSABLE — may already exist]
- **code:** `running-code-generator`
- **name:** Running Code Generator (per-bucket counter)
- **category:** utility
- **input:** `{ pattern: "V-{country}-{type}-{N5}", bucket: "TH-MN" }`
- **output:** `{ code: "V-TH-MN-00003", next_n: 3 }`
- **Used by features:** F-VENDOR-MASTER-001 (vendor code), potentially F-PO-001 (PO number), F-PV-001 (PV number)
- **Implementation note:** must handle race conditions — use DB sequence per bucket OR INSERT with retry on UQ violation

### ENG-PRICE-LIST-PROXY: `price-list-proxy` ⭐ NEW v1.1 [CONSUMER — calls F-VENDOR-PRICE-LIST]
- **code:** `price-list-proxy`
- **name:** Vendor Price List Proxy (read-only consumer)
- **category:** cross-feature-integration
- **module:** Vendor Master (consumer); data source = F-VENDOR-PRICE-LIST
- **input schema:**
  ```json
  { "tenant_id": "uuid", "vendor_id": "uuid", "limit": 50 }
  ```
- **output schema:**
  ```json
  {
    "items": [{ "code": "string", "name": "string", "price": "number", "unit": "string", "status": "active|expired" }],
    "total": "number",
    "active_count": "number",
    "expired_count": "number",
    "updated_at": "ISO8601"
  }
  ```
- **logic outline:**
  1. Authenticate caller (must have vendor:read permission)
  2. Call F-VENDOR-PRICE-LIST internal API (gRPC or HTTP) — `getSummary(tenantId, vendorId, limit)`
  3. Apply field whitelist (strip category, minQty, validFrom, validTo, etc — only return 5 fields)
  4. Handle errors: timeout (3s), 5xx, 404 → return empty items + log
  5. Return projected response
- **Used by features:** F-VENDOR-MASTER-001 (Tab 5 read-only view) — Phase 2 wire-up
- **Phase 1:** mock data inline in HTML (`PRICE_LIST_BY_VENDOR` const) — engine not yet invoked
- **Iron rule check:** ✅ pure proxy, no business logic, no HTTP terms in interface
- **R8 status:** Consumer engine (not a mutation engine) — does not require R8 trace from mutation APIs · documented for cross-feature integration clarity

---

## §3.3 API ↔ Logic Trace Table (R8 Anchor)

| API | Method | Function(s) | Engine(s) |
|---|---|---|---|
| API-01 GET /vendors | — | (read) | ENG-DATA-CLASSIFICATION |
| API-02 GET /vendors/{id} | — | (read) | ENG-DATA-CLASSIFICATION |
| API-03 POST /vendors | mutation | FN-01 createVendor | ENG-CODE-GEN |
| API-04 PATCH /vendors/{id} | mutation | FN-02 updateVendor, FN-15 isImmutableTax | — |
| API-05 POST /submit-kyc | mutation | FN-03 submitForKyc | — |
| API-06 POST /kyc-review | mutation | FN-04 reviewKyc | **ENG-SANCTIONS** |
| API-07 POST /submit-approval | mutation | FN-05 submitForApproval, FN-06 autoApproveOneTime | **ENG-DOA-CHAIN** |
| API-08 POST /approve | mutation | FN-07 approveCurrentStep, FN-18 canApproveCurrent, FN-19 chainDone | — |
| API-09 POST /reject | mutation | FN-08 rejectApproval | — |
| API-10 POST /banks/{idx}/verify | mutation | FN-09 verifyBankAccount | — |
| API-11 POST /block | mutation | FN-10 blockVendor | — |
| API-12 POST /unblock | mutation | FN-11 unblockVendor | — |
| API-13 POST /blacklist | mutation | FN-12 blacklistVendor | — |
| API-14 GET /audit | — | (read) | — |
| API-15 GET /_next-code | — | FN-13 genVendorCode | ENG-CODE-GEN |
| **API-16 GET /price-list-summary ⭐ NEW v1.1** | — | **FN-20 fetchPriceListSummary** | **ENG-PRICE-LIST-PROXY** |

### Trace Verification (Self-Check)
- **Total mutation APIs:** 11
- **All traced to FN:** 11/11 ✅
- **Engines invoked (v1.1):** 5 (ENG-DOA-CHAIN, ENG-SANCTIONS, ENG-DATA-CLASSIFICATION, ENG-CODE-GEN, **ENG-PRICE-LIST-PROXY**)
- **R8 Compliance:** ✅ 100% (unchanged — API-16 is GET, not mutation)

## §3.4 Dependencies

### External Functions/Engines called

| Called from | What | When |
|---|---|---|
| FN-04 reviewKyc | ENG-SANCTIONS (Compliance) | KYC review |
| FN-05 submitForApproval | ENG-DOA-CHAIN (Policy Center, Phase 2) | Building chain |
| API masking layer | ENG-DATA-CLASSIFICATION (Policy Center, Phase 2) | Every read response |
| FN-13, FN-01 | ENG-CODE-GEN (Core Cube) | Vendor code generation |
| All FN with audit | Core Cube · WORM Audit Logger | Every mutation |

### External Functions/Engines that call into this feature

| Caller | What | Phase |
|---|---|---|
| F-PR-001 (Purchase Request) | API-01 list, API-02 get | Phase 1+ |
| F-PO-001 (Purchase Order) | API-02 get, validate vendor status=active | Phase 1+ |
| F-PV-001 (Payment Voucher) | API-02 get, check banks[*].verified | Phase 1+ |
| F-AP-001 (Invoice/AP) | API-02 get | Phase 2+ |
| F-GR-001 (Goods Receipt) | API-02 get | Phase 1+ |

## §3.5 Open Questions / Locked Decisions Referenced

- **OQ-01** (DOA chain rule actual) → ENG-DOA-CHAIN config — promoted to **LD-03** (engine candidate)
- **OQ-02** (Classification engine format) → ENG-DATA-CLASSIFICATION schema — promoted to **LD-04**
- **OQ-03** (Sanctions API source) → ENG-SANCTIONS implementation
- **LD-05** (decision): Phase 1 uses inline placeholder; Phase 2 wires to engines without UI change

---

## Audience Cheat-Sheet

- **FE Dev:** focus on UI behavior — `canApproveCurrent`, `isImmutableTax`, `hasValidContact` are mirrored in HTML for instant feedback (server is authoritative)
- **BE Dev:** FN-01 to FN-19 are the implementation contract; pure functions where possible (testable in isolation)
- **DBA:** mutation functions all write to WORM audit — INSERT-only grant on `T_audit`
- **Architect:** 4 engines (DOA / SANCTIONS / CLASSIFICATION / CODE-GEN) are reusable across features; register CUBIC during Phase 2
- **QA:** test each FN in isolation + integration test through API
