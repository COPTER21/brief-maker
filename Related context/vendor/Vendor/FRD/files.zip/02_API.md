# 02_API — F-VENDOR-MASTER-001 Vendor Master

> Audience: BE Dev, FE Dev (HTTP layer)
> All endpoints under `/api/v1/vendors` · tenant scoping via `X-Tenant-ID` header
> Auth: Bearer token (SSO via CUBE Auth) · MFA enforced for sensitive ops
> **v1.1:** Added API-16 (Price List summary proxy from F-VENDOR-PRICE-LIST)

## §2.1 API Overview

| API ID | Method | Path | Purpose | Roles |
|---|---|---|---|---|
| API-01 | GET | `/api/v1/vendors` | List vendors (paginated, filtered) | All 6 |
| API-02 | GET | `/api/v1/vendors/{id}` | Get vendor by ID (full detail) | All 6 (masked per role) |
| API-03 | POST | `/api/v1/vendors` | Create vendor (status=prospect) | Officer, Admin |
| API-04 | PATCH | `/api/v1/vendors/{id}` | Update vendor (optimistic locking via version) | Officer, Admin |
| API-05 | POST | `/api/v1/vendors/{id}/submit-kyc` | Transition prospect → pending_kyc | Officer, Admin |
| API-06 | POST | `/api/v1/vendors/{id}/kyc-review` | Compliance review (pass/fail/sanctions) | Compliance, Admin |
| API-07 | POST | `/api/v1/vendors/{id}/submit-approval` | Transition pending_kyc → pending_approval (build chain) | Officer, Admin |
| API-08 | POST | `/api/v1/vendors/{id}/approve` | Approve current chain step | Per step role |
| API-09 | POST | `/api/v1/vendors/{id}/reject` | Reject (back to pending_kyc, clear chain) | Per step role |
| API-10 | POST | `/api/v1/vendors/{id}/banks/{idx}/verify` | Finance verify bank account | Finance, Admin |
| API-11 | POST | `/api/v1/vendors/{id}/block` | Block active vendor | Procurement, Admin |
| API-12 | POST | `/api/v1/vendors/{id}/unblock` | Unblock (back to active) | Procurement, Admin |
| API-13 | POST | `/api/v1/vendors/{id}/blacklist` | Terminal blacklist | Director, Admin |
| API-14 | GET | `/api/v1/vendors/{id}/audit` | Read WORM audit log | Internal Audit, Admin |
| API-15 | GET | `/api/v1/vendors/_next-code` | Preview next auto-gen code (country+type) | Officer, Admin |
| **API-16 ⭐ NEW v1.1** | **GET** | **`/api/v1/vendors/{id}/price-list-summary`** | **Fetch Price List summary (proxy to F-VENDOR-PRICE-LIST)** | **All 6 (view-only)** |

## §2.2 Per-API Contract

### F-VENDOR-MASTER-001-API-01: GET /api/v1/vendors

**Query params:**
- `search` (string, optional) — match against code/name/tax_id
- `type` (enum 11) — filter by vendor type
- `status` (enum 6) — filter by status
- `page` (int, default 1)
- `pageSize` (int, default 20, max 100)
- `sortBy` (enum: `code`, `name`, `type`, `status`, `created`)
- `sortDir` (enum: `asc`, `desc`)

**Response 200:**
```json
{
  "records": [{ "id": "V001", "code": "V-TH-MN-00001", "name": "...", "type": "MN", "tax": "0105••••67", "status": "active", "kyc": "passed", ... }],
  "total": 14, "page": 1, "pageSize": 20, "totalPages": 1
}
```

**Notes:**
- Masking applied per role at this layer (see §2.3 Masking)
- Audit log: read events not logged (only mutations)

### F-VENDOR-MASTER-001-API-02: GET /api/v1/vendors/{id}

**Response 200:** full vendor object with masking applied
- `tax`, `vat`, `companyReg` → masked unless role ∈ {Finance, Compliance, Admin}
- `creditLimit` → masked (null + flag `_masked: true`) for non-Finance/Compliance/Admin
- `banks[*].acct` → masked unless role ∈ {Finance, Admin}

**Response 404:** vendor not found
**Response 403:** tenant mismatch

### F-VENDOR-MASTER-001-API-03: POST /api/v1/vendors

**Headers:**
- `Idempotency-Key` (required) — prevents double-create on retry (PR-7)

**Body:**
```json
{
  "name": "...", "display": "...", "type": "MN", "country": "TH",
  "tax": "0105551234567", "vat": "...", "companyReg": "...",
  "currency": "THB", "term": "NET30", "wht": 3, "creditLimit": 1000000,
  "contacts": [...], "addresses": [...], "banks": [...], "attachments": [...]
}
```

**Logic invocation:** Calls `FN-01 createVendor` (see 03_LOGIC §3.1)

**Response 201:**
```json
{ "id": "V015", "code": "V-TH-MN-00003", "status": "prospect", "version": 1, "created": "..." }
```

**Response 422:** validation errors (per-field array)
**Response 409:** duplicate tax_id in same country (`DUPLICATE_TAX_ID`)

### F-VENDOR-MASTER-001-API-04: PATCH /api/v1/vendors/{id}

**Headers:**
- `If-Match: {version}` (required) — optimistic locking (PR-2)

**Body:** partial vendor (only changed fields)

**Logic:** Calls `FN-02 updateVendor` → enforces IR-01 (tax_id locked if kyc=passed)

**Response 200:** updated vendor (full)
**Response 409:** version mismatch (`STALE_VERSION`)
**Response 422:** `IMMUTABLE_TAX_ID` if attempting to modify locked tax_id
**Response 403:** edit not allowed in current status (see BR-L02)

### F-VENDOR-MASTER-001-API-05: POST /api/v1/vendors/{id}/submit-kyc

**Body:** `{}` (empty — action only)

**Logic:** `FN-03 submitForKyc` — transition prospect → pending_kyc

**Response 200:** vendor with new status
**Response 409:** `INVALID_TRANSITION` if status ≠ prospect

### F-VENDOR-MASTER-001-API-06: POST /api/v1/vendors/{id}/kyc-review

**Body:**
```json
{
  "result": "passed" | "failed",
  "sanctions_hit": boolean,
  "reviewed_documents": ["att_001", "att_002"],
  "notes": "string (optional)"
}
```

**Logic:** `FN-04 reviewKyc` — invokes `ENG-SANCTIONS` if not pre-checked

**Response 200 (passed):** `{ kyc: "passed", kycAt: "...", tax_locked: true }`
**Response 200 (failed):** `{ kyc: "failed", kycAt: "..." }` (status still pending_kyc)
**Response 200 (sanctions hit):** `{ kyc: "failed", status: "blocked", block: "พบรายชื่อต้องห้าม (sanctions hit)" }`
**Response 403:** role ≠ Compliance/Admin

### F-VENDOR-MASTER-001-API-07: POST /api/v1/vendors/{id}/submit-approval

**Body:** `{}` (empty)

**Logic:** `FN-05 submitForApproval` — calls `ENG-DOA-CHAIN` to resolve chain
- If OT type → auto-approve (skip pending_approval, go to active) — `FN-06`
- Else → build chain, set status=pending_approval

**Response 200 (non-OT):** `{ status: "pending_approval", approvalChain: [{ seq:1, role:"...", label:"...", status:"pending", ... }] }`
**Response 200 (OT):** `{ status: "active", approvedBy: "ระบบ (auto)", approvedAt: "..." }`
**Response 422:** `KYC_NOT_PASSED` or `NOT_READY` (contact/bank check)

### F-VENDOR-MASTER-001-API-08: POST /api/v1/vendors/{id}/approve

**Body:** `{ "comment": "string (optional)" }`

**Logic:** `FN-07 approveCurrentStep` — guards: KYC, SoD, role match step, ready
- Mark current step approved
- If chain done → transition to active
- Else → stay pending_approval, advance to next step

**Response 200 (mid-chain):** `{ approvalChain: [...updated], status: "pending_approval", nextStep: {...} }`
**Response 200 (chain complete):** `{ status: "active", approvedBy: "...", approvedAt: "..." }`
**Response 422:**
- `KYC_NOT_PASSED`
- `SOD_VIOLATION`
- `WRONG_APPROVER` (role mismatch + not Director/Admin override)
- `NOT_READY`

### F-VENDOR-MASTER-001-API-09: POST /api/v1/vendors/{id}/reject

**Body:** `{ "reason": "string (required, min 5 chars)" }`

**Logic:** `FN-08 rejectApproval` — transition pending_approval → pending_kyc, clear approvalChain

**Response 200:** `{ status: "pending_kyc", approvalChain: [], rejectedBy: "...", rejectedAt: "..." }`
**Response 422:** `REASON_REQUIRED` if reason empty
**Response 403:** role lacks rights (must match current step OR Director/Admin)

### F-VENDOR-MASTER-001-API-10: POST /api/v1/vendors/{id}/banks/{idx}/verify

**Body:** `{}` (empty)

**Logic:** `FN-09 verifyBankAccount` — sets bank[idx].verified = true

**Response 200:** updated vendor (bank section)
**Response 403:** role ≠ Finance/Admin
**Response 422:** `SOD_VIOLATION` if Finance user = creator

### F-VENDOR-MASTER-001-API-11: POST /api/v1/vendors/{id}/block

**Body:** `{ "reason": "string (required)" }`

**Logic:** `FN-10 blockVendor`

**Response 200:** `{ status: "blocked", block: "..." }`
**Response 422:** `REASON_REQUIRED` or `INVALID_TRANSITION` (status ≠ active)

### F-VENDOR-MASTER-001-API-12: POST /api/v1/vendors/{id}/unblock

**Body:** `{ "reason": "string (required)" }`

**Logic:** `FN-11 unblockVendor`

**Response 200:** `{ status: "active", block: "" }`
**Response 422:** `REASON_REQUIRED` or `INVALID_TRANSITION`

### F-VENDOR-MASTER-001-API-13: POST /api/v1/vendors/{id}/blacklist

**Body:** `{ "reason": "string (required)" }`

**Logic:** `FN-12 blacklistVendor` — terminal transition

**Response 200:** `{ status: "blacklisted", block: "..." }`
**Response 403:** `BLACKLIST_REQUIRES_DIRECTOR` if role ≠ Director/Admin

### F-VENDOR-MASTER-001-API-14: GET /api/v1/vendors/{id}/audit

**Query:** `limit` (default 100, max 500), `since` (ISO timestamp)

**Response 200:**
```json
{
  "entries": [
    { "t": "อนุมัติขั้น 2 (ผู้อำนวยการจัดซื้อ)", "by": "วิชัย ผอ.จัดซื้อ", "at": "2026-05-14T10:30:00", "v": "success" },
    ...
  ],
  "total": 8
}
```

**Notes:** read-only; WORM enforcement at DB layer (no UPDATE/DELETE grant)
**Response 403:** role ∉ {Internal Audit, Admin, Compliance}

### F-VENDOR-MASTER-001-API-15: GET /api/v1/vendors/_next-code

**Query:** `country` (ISO-2), `type` (enum)

**Response 200:** `{ "code": "V-TH-MN-00003" }`

**Logic:** `FN-13 genVendorCode` — preview only; finalized on actual create

### F-VENDOR-MASTER-001-API-16: GET /api/v1/vendors/{id}/price-list-summary ⭐ NEW v1.1

**Purpose:** Fetch a minimal Price List summary for the View Drawer Tab 5 (read-only embed). Proxy to F-VENDOR-PRICE-LIST feature.

**Query params:**
- `limit` (int, default 50, max 100) — top-N items

**Response 200:**
```json
{
  "vendor_id": "V001",
  "updated_at": "2026-05-20T09:00:00Z",
  "items": [
    {
      "code": "P-STL-001",
      "name": "เหล็กเส้นกลม SR24 ø12mm",
      "price": 185.00,
      "unit": "เส้น 10m",
      "status": "active"
    }
  ],
  "total": 5,
  "active_count": 5,
  "expired_count": 0,
  "source": "F-VENDOR-PRICE-LIST",
  "cache_hit": true,
  "cache_ttl_remaining_s": 245
}
```

**Response 200 (no price list):**
```json
{ "vendor_id": "V007", "items": [], "total": 0, "source": "F-VENDOR-PRICE-LIST" }
```

**Response 404:** vendor not found (in Vendor Master)
**Response 502 (Bad Gateway):** F-VENDOR-PRICE-LIST API unavailable → UI shows fallback message "ไม่สามารถดึง Price List ได้ — ลองใหม่ภายหลัง"
**Response 403:** caller lacks vendor:read permission

**Logic:** `FN-20 fetchPriceListSummary` — proxies to F-VENDOR-PRICE-LIST + applies field filtering + caches

**Caching:**
- Layer: Redis (TTL = 5 min, key = `pls:{tenant_id}:{vendor_id}`)
- Invalidation triggers (in Phase 2): F-VENDOR-PRICE-LIST publishes invalidation event when items are mutated → Vendor Master subscribes + clears cache key
- Phase 1: in-HTML mock data (no actual API call)

**Field filtering at proxy layer:** Strip out fields not used by Tab 5 (category, minQty, validFrom, validTo) to reduce payload size · BR-X01 enforces this

**Read-only:** No POST/PATCH/DELETE companion endpoints in Vendor Master · all mutations go directly to F-VENDOR-PRICE-LIST

## §2.3 Common Concerns

### Idempotency (PR-7)
- POST endpoints (create, lifecycle actions) accept `Idempotency-Key` header
- Server caches result for 24 hours; same key + same body → return cached response
- Different body with same key → 409 `IDEMPOTENCY_CONFLICT`

### Optimistic Locking (PR-2)
- PATCH endpoints require `If-Match: {version}` header
- Server checks `vendor.version === request.version`
- On mismatch → 409 `STALE_VERSION` with current version
- On success → increment version

### Multi-Tenant
- All requests scoped by `X-Tenant-ID` header (injected by API gateway from JWT)
- DB queries auto-filtered by tenant_id (RLS or app-layer)
- Cross-tenant access → 404 (not 403, to prevent enumeration)

### Audit Log
- Every mutation API writes audit entry **before** returning success
- Audit is WORM — INSERT-only DB grant
- If audit write fails → entire transaction rolls back (`AUDIT_WRITE_FAILED`, critical alert)

### Masking (per-role at API gateway middleware)

| Field | Public/Internal | Confidential mask roles | Restricted mask roles |
|---|---|---|---|
| `tax`, `vat`, `companyReg` | — | Procurement (Officer/Mgr/Director) | — |
| `creditLimit` | — | Procurement (Officer/Mgr/Director) | — |
| `banks[*].acct` | — | — | All except Finance/Admin |

Mask pattern:
- Tax (13 digits): `0105••••••67` (4 prefix + dots + 2 suffix)
- Bank acct: `0123••••44` (3 prefix + dots + 2 suffix)
- creditLimit (masked): `null` + `_masked: true` flag

## §2.4 API → Logic Trace (Anchor for R8)

| API | Method | Trace to Function | Trace to Engine |
|---|---|---|---|
| API-03 Create | POST `/vendors` | FN-01 createVendor | (ENG-CODE-GEN inline) |
| API-04 Update | PATCH `/vendors/{id}` | FN-02 updateVendor | — |
| API-05 Submit KYC | POST `/submit-kyc` | FN-03 submitForKyc | — |
| API-06 KYC Review | POST `/kyc-review` | FN-04 reviewKyc | **ENG-SANCTIONS** |
| API-07 Submit Approval | POST `/submit-approval` | FN-05 submitForApproval + FN-06 (OT auto) | **ENG-DOA-CHAIN** |
| API-08 Approve | POST `/approve` | FN-07 approveCurrentStep | — |
| API-09 Reject | POST `/reject` | FN-08 rejectApproval | — |
| API-10 Verify Bank | POST `/banks/{idx}/verify` | FN-09 verifyBankAccount | — |
| API-11 Block | POST `/block` | FN-10 blockVendor | — |
| API-12 Unblock | POST `/unblock` | FN-11 unblockVendor | — |
| API-13 Blacklist | POST `/blacklist` | FN-12 blacklistVendor | — |
| API-15 Next Code | GET `/_next-code` | FN-13 genVendorCode | — |
| **API-16 Price List Summary ⭐ NEW v1.1** | GET `/{id}/price-list-summary` | **FN-20 fetchPriceListSummary** | **ENG-PRICE-LIST-PROXY** (consumer of F-VENDOR-PRICE-LIST) |
| (API-02 Get) | GET `/{id}` | (read path) | **ENG-DATA-CLASSIFICATION** (masking) |
| (API-01 List) | GET `/vendors` | (read path) | ENG-DATA-CLASSIFICATION |

**R8 Compliance: 100% — every mutation API has trace to FN/ENG in 03_LOGIC.**
**v1.1 note:** API-16 is read-only (GET) — no R8 mutation trace required, but documented FN-20 for consistency.
