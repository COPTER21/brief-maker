# 00_OVERVIEW — F-VENDOR-MASTER-001 Vendor Master

## §0.1 Document Control

| Field | Value |
|---|---|
| FRD ID | FRD-P2P-MD-VENDOR-001 |
| Feature Code | F-VENDOR-MASTER-001 |
| Feature Name | Vendor Master (ทะเบียนคู่ค้า) |
| Pack Variant | **FULL** (9 + INDEX) |
| Version | 1.1 |
| Status | Draft → Mechanical Verified (Revised) |
| Owner | 2BSimple BA Team |
| Module | Master Data · P2P Domain · CUBE NATIVE |
| Generator | frd-generator-v5 v5.1 |
| Source BRD | `BRD_vendor_master.md` v1.1 (APPROVED) |
| Source HTML | `vendor-master.html` v2 (Production-ready prototype, 5-tab view drawer) |
| Created | 2026-05-29 |
| Last Updated | 2026-05-31 (v1.1) |

## §0.2 Revision History

| Version | Date | Changes |
|---|---|---|
| 1.0 | 2026-05-29 | Initial FRD generated from BRD v1.0 + HTML prototype via frd-generator-v5 |
| **1.1** | **2026-05-31** | **Revision per BRD v1.1 + HTML v2 — Tab 5 "สินค้า/บริการ" (read-only Price List embed from F-VENDOR-PRICE-LIST). Affects 01_UI (P-04 tab 5), 02_API (+API-16), 03_LOGIC (+FN-20, +ENG-PRICE-LIST-PROXY consumer), 05_RULES (+BR-X01 cross-feature read-only), 06_TESTS (+AC-28 to AC-30), 07_LOCKED_DECISIONS (+LD-11, +LD-12), INDEX (cross-ref updates, R8 verification still 100%)** |

## §0.3 Scope

### In Scope (Phase 1 MVP)
- CRUD vendor master (11 vendor types) + auto-gen code `V-{CC}-{TT}-{NNNNN}`
- 6-state lifecycle: prospect → pending_kyc → pending_approval → active ↔ blocked → blacklisted
- KYC gate with sanctions screening (stub for OFAC/UN/EU)
- DOA approval chain — placeholder rule by credit limit, wire-ready for Policy Center DOA Engine
- Multi-bank with Finance verification + primary toggle + Restricted classification
- Multi-contact + multi-address (Thai address master)
- Role-based masking (Confidential: tax_id; Restricted: bank_account)
- WORM audit logging (every action)
- 6 roles (Procurement Officer/Manager/Director, Finance, Compliance, Admin)
- 3-step create wizard + view drawer with **5 tabs** + 6 confirmation modals
- **Tab 5 "สินค้า/บริการ" (read-only Price List embed)** ⭐ NEW v1.1 — compact table view (name + price/unit + status), data fetched from F-VENDOR-PRICE-LIST API; no CRUD in this tab

### Out of Scope (deferred)
- **Price List CRUD** ⭐ — manage items/prices/validity → **F-VENDOR-PRICE-LIST feature** (separate; Phase 2 build)
- Vendor merge/split (Phase 2)
- Vendor performance scoring (Phase 3)
- Vendor portal — external login (Phase 3)
- Real DOA Engine implementation (Phase 2 — placeholder ใน Phase 1)
- Real Data Classification engine (Phase 2)
- Payment Terms master (lives in Finance domain — vendor only references code)
- PDPA consent management + anonymization tool (Phase 2)
- Vendor analytics dashboard (Phase 4)

### Out of Scope (from Phase 2.5 probing — declined edge cases)
- Bulk import from Excel (Phase 1.5 only)
- Multi-currency credit limit (single-currency only ใน Phase 1)
- Currency FX conversion at approval (assumes credit limit in THB)

## §0.4 Roles & Responsibilities (COSO)

| Role | Maker | Checker | Approver | System |
|---|:---:|:---:|:---:|:---:|
| **Procurement Officer** | ✅ (create/edit/submit) | — | ✅ (DOA step 1 ที่ credit ต่ำ) | — |
| **Procurement Manager** | — | ✅ (review pre-submit option) | ✅ (DOA step 1-2) | — |
| **Procurement Director** | — | — | ✅ (any DOA step via override) + blacklist | — |
| **Finance** | — | ✅ (bank account verify) | — | — |
| **Compliance** | — | ✅ (KYC review) | — | — |
| **Admin** | ✅ | ✅ | ✅ (override) | — |
| **System** | — | — | — | sanctions check, audit log, OT auto-approve |

**SoD enforcement:**
- SoD-01: ผู้สร้าง (createdBy) ≠ ผู้อนุมัติ (approver in any chain step)
- SoD-02: Compliance (KYC) ≠ Procurement (DOA)
- SoD-03: Finance (bank verify) ≠ ผู้สร้าง vendor

## §0.5 Dependencies

### Upstream (this feature depends on)
- **Core Cube · Country Master** (ISO 3166 alpha-2)
- **Core Cube · Currency Master** (ISO 4217 + FX rate)
- **Core Cube · Bank Master** (Thai banks + foreign)
- **Core Cube · Thai Address Master** (จังหวัด/อำเภอ/ตำบล + postal code)
- **Finance · Payment Terms Master** ⭐ — vendor stores code; definition lives there
- **Policy Center · DOA Engine** ⚠️ Phase 2 (placeholder rule in Phase 1)
- **Policy Center · Data Classification Engine** ⚠️ Phase 2 (hardcoded mask in Phase 1)
- **ENG-SANCTIONS** (Compliance) — OFAC/UN/EU feed
- **Core Cube · WORM Audit Logger**
- **Auth Service** — SSO + MFA + RBAC
- **F-VENDOR-PRICE-LIST** ⭐ NEW v1.1 — Phase 2 feature; Phase 1 uses inline mock data in HTML; provides `GET /api/v1/vendors/{id}/price-list-summary` for Tab 5

### Downstream (features that depend on this)
- F-PR-001 Purchase Request — vendor selector
- F-PO-001 Purchase Order — vendor + payment term + tax
- F-GR-001 Goods Receipt — vendor reference
- F-PV-001 Payment Voucher — vendor + verified bank gate
- F-AP-001 Invoice/AP — vendor + tax info

### External
- OFAC/UN/EU sanctions API (commercial — TBD per OQ-03)
- Thai Revenue Department checksum validation (for 13-digit tax ID)

## §0.6 Stack & Architecture

| Layer | Technology | Notes |
|---|---|---|
| Frontend | HTML SPA (vanilla JS + Tailwind utility) | reference: `vendor-master.html` v1, Iron Rules 30/30 ของ html-generator-v3 v3.6 |
| Backend API | REST + GraphQL | CUBE NATIVE standard |
| Business Logic | Functions (scope-local) + Engines (CUBIC reusable) | DOA / Classification / Sanctions as Engines |
| Database | PostgreSQL | JSONB for `approvalChain`, `audit`, sub-arrays |
| Audit | PostgreSQL WORM table | INSERT-only grant; no UPDATE/DELETE |
| Search | Database indexes + (optional) Elasticsearch | for ≥10k vendors |
| Cache | Redis | for masters (country/currency/bank) |

## §0.7 Multi-Tenant & Security Context

- **Multi-tenant:** Yes — vendor scoped by `tenant_id` (added at API gateway)
- **PII fields:** tax_id, vat, companyReg, contact.email, contact.phone, contact.name
- **Sensitive financial:** creditLimit, bank.acct, bank.name
- **Authentication:** SSO via CUBE Auth + MFA
- **Authorization:** RBAC — 6 roles × 9 actions matrix (see BRD §4.1)
- **Encryption at rest:** AES-256 for all Confidential + Restricted fields
- **Encryption in transit:** TLS 1.3 minimum
- **API masking:** enforced at API gateway middleware (per-role visibility)

### §0.7.1 Data Classification Summary ⭐ (v5.1)

| Highest Level | Count of fields | Fields | Policy Center Linkage |
|---|---|---|---|
| **Restricted** (highest) | 1 | `bank_account.acct` | Restricted Resources registry |
| **Confidential** | 4 | `vendor.tax_id`, `vendor.vat`, `vendor.companyReg`, `vendor.creditLimit` | Data Classification module |
| **Internal** | (default) | everything else (name, type, status, audit ฯลฯ) | — |
| **Public** | 0 | — | — |

**PII overlay (independent flag):** `contact.name`, `contact.email`, `contact.phone`, `vendor.name` (when EM type = พนักงาน)

## §0.8 Open Questions

| # | Question | Owner | Target | Promoted to LD |
|---|---|---|---|---|
| OQ-01 | DOA chain rule actual (placeholder by creditLimit) | Policy Center team | Phase 2 | LD-03 |
| OQ-02 | Data Classification engine config format | Policy Center team | Phase 2 | LD-04 |
| OQ-03 | Sanctions API source (Refinitiv / Dow Jones / in-house?) | Compliance | Phase 1 | — |
| OQ-04 | KYC expiry policy (yearly review?) | Compliance | Phase 1 | — |
| OQ-05 | Rename `pending_kyc` label? | UX + BA | Phase 1 | — |
| OQ-06 | Bank account length per bank (master vs hardcoded) | Core Cube | Phase 1.5 | — |
| OQ-07 | PDPA delete flow detail (anonymize vs hard delete) | Legal + Compliance | Phase 2 | — |
| OQ-08 | Vendor migration format from Excel | Pilot clients | Phase 1.5 | — |
| **OQ-09 ⭐ NEW v1.1** | **F-VENDOR-PRICE-LIST API contract** — endpoint shape, auth model, cache TTL, paging (vendors with > 100 items), edge cases (vendor deleted while price list still has refs) | **F-VENDOR-PRICE-LIST team + Vendor Master BA** | **Phase 2 kickoff** — must finalize before implementing real Tab 5 integration |

## §0.9 Glossary

| Term | Definition |
|---|---|
| **DOA** | Delegation of Authority — chain of approvers based on policy |
| **KYC** | Know-Your-Customer — identity verification gate |
| **SoD** | Separation of Duties — maker ≠ approver |
| **WORM** | Write-Once-Read-Many — immutable audit log |
| **OT (One-time)** | Single-use vendor — auto-approve, no chain |
| **IR-01** | Immutable Rule 01 — tax_id locked after KYC pass |
| **R8** | Iron Rule 8 — every mutation API traces to a Function/Engine |
| **R10** | Iron Rule 10 — Data Classification mandatory per column |

## §0.10 Pack Navigation

| File | Audience | Content |
|---|---|---|
| 00_OVERVIEW.md | All | Document control, scope, roles, dependencies, classification summary |
| 01_UI.md | FE Dev, UX | Pages + components + journey + Layout Template IDs |
| 02_API.md | BE Dev, FE Dev | REST API contracts (HTTP layer) |
| 03_LOGIC.md | BE Dev, Architect | Functions + Engines (business logic, R8 anchor) |
| 04_DB.md | DBA, BE Dev | Tables + indexes + classification per column (R10) |
| 05_RULES.md | BE Dev, QA, BA | Business rules + state machine + edge cases |
| 06_TESTS.md | QA, Dev | Acceptance criteria + DoD |
| 07_LOCKED_DECISIONS.md | Architect, PM | LDs + convention deviations + tradeoffs |
| INDEX.md | All | Cross-ref + Quick Nav + R8 verification matrix |
