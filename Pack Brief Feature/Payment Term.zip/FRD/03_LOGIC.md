# 03_LOGIC — F-PAYMENT-TERM-001 เงื่อนไขการชำระเงิน

> Audience: BE dev (business logic layer)
> Scope: non-HTTP logic — functions, validations, calculations

---

## §3.1 Functions (Scope-Local)

### F-PT-FN-01: createPaymentTerm
- **Purpose:** สร้าง payment term ใหม่ + installments (ถ้ามี)
- **Input:** `{ code, name, type, trigger, ...config, use_in[], is_default, installments?[] }`
- **Output:** `PaymentTerm | ValidationError[]`
- **Invoked by:** F-PT-API-03
- **Calls:** F-PT-FN-06 (validate), ENG-PT-01 (installment-validator ถ้า installment), ENG-PT-02 (trigger-resolver), F-PT-FN-07 (clearDefault ถ้า is_default)
- **Side effects:** INSERT T_payment_term (+ T_payment_term_installment), audit log
- **Iron rule check:** ✅ no HTTP terms

### F-PT-FN-02: updatePaymentTerm
- **Purpose:** แก้ไข payment term — ถ้าเปลี่ยน type → reset config เฉพาะประเภท (preserve code/name/use_in)
- **Input:** `{ id, ...fields }`
- **Output:** `PaymentTerm | ValidationError[]`
- **Invoked by:** F-PT-API-04
- **Calls:** F-PT-FN-06, ENG-PT-01, ENG-PT-02, F-PT-FN-07
- **Side effects:** UPDATE + replace installments, audit log (before/after — S01-07)

### F-PT-FN-03: setPaymentTermStatus
- **Purpose:** archive (soft-delete) / reactivate
- **Input:** `{ id, status }`
- **Output:** `{ id, status }`
- **Invoked by:** F-PT-API-05
- **Side effects:** UPDATE status, audit log

### F-PT-FN-04: importPaymentTerms
- **Purpose:** นำเข้า CSV — replace (ลบเก่าก่อน) หรือ merge
- **Input:** `{ mode, rows[] }`
- **Output:** `{ imported, skipped, errors[] }`
- **Invoked by:** F-PT-API-06
- **Calls:** F-PT-FN-06 (validate ต่อ row), F-PT-FN-08 (mapCsvRowToTerm)
- **Side effects:** DELETE (ถ้า replace) + bulk INSERT, audit log

### F-PT-FN-05: buildPaymentTermQuery
- **Purpose:** สร้าง query สำหรับ list (search code/name/name_en + filter type/status)
- **Input:** `{ q, type, status, tenant_id }`
- **Output:** SQL/ORM query
- **Invoked by:** F-PT-API-01

### F-PT-FN-06: validatePaymentTerm
- **Purpose:** validate รวมศูนย์ (ใช้ทั้ง create/update/import)
- **Input:** `PaymentTermInput`
- **Output:** `ValidationError[]`
- **Invoked by:** F-PT-FN-01, F-PT-FN-02, F-PT-FN-04
- **Logic:** เช็ค BR-01..10 (code unique, installment sum=100 min2, deposit %≤100, credit days>0, use_in≥1, direct_payment disable docs, after_deposit เฉพาะ deposit)

### F-PT-FN-07: clearDefaultOfType
- **Purpose:** ล้าง is_default ของ records อื่นใน type เดียวกัน (default unique)
- **Input:** `{ type, exceptId, tenant_id }`
- **Output:** void
- **Invoked by:** F-PT-FN-01, F-PT-FN-02
- **Side effects:** UPDATE is_default=false

### F-PT-FN-08: mapCsvRowToTerm
- **Purpose:** แปลง CSV row → PaymentTerm object (เติม default trigger/use_in ตาม type)
- **Input:** `CsvRow`
- **Output:** `PaymentTermInput`
- **Invoked by:** F-PT-FN-04

---

## §3.2 Engines (Reusable / CUBIC-Registered)

### ENG-PT-01: installment-validator
- **code:** `installment-validator`
- **name:** Installment Schedule Validator
- **category:** finance-validation
- **input schema:** `{ installments: [{ pct, days, due_type }] }`
- **output schema:** `{ valid: boolean, errors[] }`
- **logic outline:**
  1. เช็คจำนวนงวด ≥2
  2. Sum(pct) ต้อง = 100
  3. (optional OQ-05) เช็ค days เรียงลำดับ
- **Used by features:** F-PAYMENT-TERM-001, F-PURCHASE-CONFIG-001 (planned)
- **Iron rule check:** ✅ pure, no HTTP

### ENG-PT-02: payment-trigger-resolver
- **code:** `payment-trigger-resolver`
- **name:** Warehouse/GRN/Ship Trigger Resolver
- **category:** finance-logic
- **input schema:** `{ type, trigger }`
- **output schema:** `{ resolvedTrigger, locked: boolean }`
- **logic outline:**
  1. credit → locked 'immediate'
  2. direct_payment → null (no trigger)
  3. deposit → อนุญาต after_deposit
  4. อื่น → ตาม trigDefault (D02)
- **Used by features:** F-PAYMENT-TERM-001, F-PURCHASE-CONFIG-001 (planned)
- **Iron rule check:** ✅ pure

---

## §3.3 API ↔ Logic Trace Table (Phase 3.5 Anchor)

| API | Calls Functions | Calls Engines |
|---|---|---|
| F-PT-API-01 GET list | F-PT-FN-05 | — |
| F-PT-API-02 GET detail | — (direct read) | — |
| F-PT-API-03 POST create | F-PT-FN-01, F-PT-FN-06, F-PT-FN-07 | ENG-PT-01, ENG-PT-02 |
| F-PT-API-04 PUT update | F-PT-FN-02, F-PT-FN-06, F-PT-FN-07 | ENG-PT-01, ENG-PT-02 |
| F-PT-API-05 PATCH status | F-PT-FN-03 | — |
| F-PT-API-06 POST import | F-PT-FN-04, F-PT-FN-06, F-PT-FN-08 | ENG-PT-01 |

> **R8 check:** ทุก mutation API (03/04/05/06) มี ≥1 Function ✅ · ไม่มี orphan ✅
