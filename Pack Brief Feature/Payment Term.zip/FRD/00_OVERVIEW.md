# 00_OVERVIEW — F-PAYMENT-TERM-001 เงื่อนไขการชำระเงิน (Payment Term)

> FRD Pack · STANDARD variant (7 files) · frd-generator-v5.1
> Source: BRD_payment_term.md (APPROVED) + payment-terms.html (reviewed)

---

## §0.1 Document Control

| รายการ | รายละเอียด |
|---|---|
| FRD ID | FRD-F-PAYMENT-TERM-001 |
| Feature | เงื่อนไขการชำระเงิน (Payment Term Master) |
| Module | การเงิน (Finance) — Finance Foundation #3 |
| Value Stream | P2P + S2C (shared master) |
| Pack Variant | STANDARD (7 files) |
| BRD Source | BRD-PAYMENT-TERM-001 v1.0 (APPROVED) |
| Layout Ref | html-generator-v3 v3.9 |
| Version | 1.0 |
| Status | Draft |

## §0.2 Pack Variant Rationale

- complexity = **Medium** (config หลายประเภท แต่ logic ตรงไปตรงมา)
- has-entity = **Yes** (payment_term + payment_term_installment)
- has-state = **Yes** (active ↔ archived — simple)
- multi-engine = **No** (2 engines: installment-validator, trigger-resolver)
- → **STANDARD** (7 files)

## §0.3 Scope

### In Scope
CRUD เงื่อนไขชำระเงิน 7 ประเภท (Full Prepay/Full Postpay/Deposit/Installment/Partial Delivery/Credit/Direct Payment), config เฉพาะประเภท (net_days/discount/deposit/installment schedule/expense_category), WH/GRN/Ship trigger, use_in 8 เอกสาร (P2P+S2C), default unique/type, CSV import, soft-delete

### Out of Scope
การคำนวณจริงในเอกสาร (PO/SO/Invoice), Vendor/Customer binding, GRN/PV/Receipt flow, 3-Way Match, Credit Note/Refund, Dunning, DOA approval engine (placeholder)

## §0.4 Roles

| Role | สิทธิ์ |
|---|---|
| Finance Officer | สร้าง/แก้ (Maker) |
| Finance Lead | อนุมัติ/archive (Approver — ผ่าน DOA เมื่อพร้อม) |
| Finance Viewer | ดูอย่างเดียว |
| System Admin | CSV import, default |

## §0.5 Dependencies

- **Upstream:** COA (F-COA-001) ✅, GL Posting Group (F-GL-POSTING-001) ✅
- **Downstream:** Purchase Config (F-PURCHASE-CONFIG-001), Vendor/Customer Master, เอกสาร P2P/S2C

## §0.6 Security Domains (Security Bible §0.1)

- **Master Data** (P3): Immutable Log (S01-07), Data Classification (S02-05), Audit (S06-03), SoD (S01-04)
- **Financial** (P4 overlay): กระทบการเงิน → audit เข้ม + approval ผ่าน DOA

## §0.7 Data Classification Summary (§0.7.1)

- ระดับสูงสุดที่ feature แตะ: **Internal**
- ไม่มี Confidential/Restricted/PII fields ใน entity นี้
- ทุก column default = Internal (ดู 04_DB §4.6)

## §0.8 Open Questions

| OQ | คำถาม | สถานะ |
|---|---|---|
| OQ-01 | DOA approval กี่ระดับ (สร้าง/แก้ payment term)? | รอ DOA engine — approver_role/approved_by/approval_chain = TODO placeholder |
| OQ-02 | due_basis สำหรับ direct_payment ต้องมีไหม (ตอนนี้ซ่อน)? | open |
| OQ-03 | archive record ที่เป็น default — block หรือ warn? | open |
| OQ-04 | archive record ที่ถูกใช้ในเอกสาร active — handle อย่างไร? | open (ขึ้นกับ feature เอกสาร) |
| OQ-05 | installment days validate เรียงลำดับไหม? | open |
| OQ-CLASS | ไม่มี Restricted field → ไม่ต้อง wire Restricted Resources registry | resolved |
