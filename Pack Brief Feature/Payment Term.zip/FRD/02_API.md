# 02_API — F-PAYMENT-TERM-001 เงื่อนไขการชำระเงิน

> Audience: BE dev (HTTP layer only) · CUBIC API schema · business logic → 03_LOGIC

---

## §2.1 Endpoints Overview

| ID | Method | Path | Purpose |
|---|---|---|---|
| F-PT-API-01 | GET | /finance/payment-terms | list + search + filter |
| F-PT-API-02 | GET | /finance/payment-terms/:id | detail |
| F-PT-API-03 | POST | /finance/payment-terms | create |
| F-PT-API-04 | PUT | /finance/payment-terms/:id | update |
| F-PT-API-05 | PATCH | /finance/payment-terms/:id/status | archive/reactivate |
| F-PT-API-06 | POST | /finance/payment-terms/import | CSV import (replace/merge) |

---

## §2.2 F-PT-API-01 GET /finance/payment-terms
- **Query:** `?q=&type=&status=`
- **Auth:** role ∈ {Officer, Lead, Viewer, Admin}
- **Response 200:** `{ data: PaymentTerm[], total }`
- **Logic:** → `buildPaymentTermQuery` (F-PT-FN-05)

## §2.3 F-PT-API-02 GET /finance/payment-terms/:id
- **Response 200:** `PaymentTerm` (+ installments[])
- **Error:** 404 `PAYMENT_TERM_NOT_FOUND`

## §2.4 F-PT-API-03 POST /finance/payment-terms
- **Auth:** role ∈ {Officer, Lead, Admin}
- **Body:** `{ code, name, name_en?, type, trigger?, net_days?, discount_pct?, discount_days?, deposit_method?, deposit_value?, remaining_timing?, expense_category?, due_basis?, use_in[], is_default, installments?[] }`
- **Request Validation (trivial, HTTP layer):** required code/name/type, use_in is array
- **Logic:** → `createPaymentTerm` (F-PT-FN-01)
- **Response 201:** `PaymentTerm`
- **Errors:** 422 `DUPLICATE_CODE`, `INSTALLMENT_SUM_INVALID`, `DEPOSIT_PCT_EXCEEDED`, `CREDIT_DAYS_INVALID`, `USE_IN_REQUIRED`

## §2.5 F-PT-API-04 PUT /finance/payment-terms/:id
- **Body:** เหมือน create
- **Logic:** → `updatePaymentTerm` (F-PT-FN-02)
- **Response 200:** `PaymentTerm`
- **Errors:** เหมือน create + 404

## §2.6 F-PT-API-05 PATCH /finance/payment-terms/:id/status
- **Auth:** Lead (archive ผ่าน DOA เมื่อพร้อม)
- **Body:** `{ status: 'active' | 'archived' }`
- **Logic:** → `setPaymentTermStatus` (F-PT-FN-03)
- **Response 200:** `{ id, status }`

## §2.7 F-PT-API-06 POST /finance/payment-terms/import
- **Auth:** Lead, Admin
- **Body:** `{ mode: 'replace' | 'merge', rows: CsvRow[] }`
- **Logic:** → `importPaymentTerms` (F-PT-FN-04)
- **Response 200:** `{ imported, skipped, errors[] }`
