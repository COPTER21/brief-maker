# 05_RULES — F-PAYMENT-TERM-001 เงื่อนไขการชำระเงิน

> Business Rules + Validation + Edge Cases + Error Catalog

---

## §5.1 Business Rules

| Rule ID | กฎ | Tag | Map |
|---|---|---|---|
| BR-01 | code unique/tenant + uppercase | FIXED | master |
| BR-02 | is_default unique/type (ตั้งใหม่ล้างเก่า) | FIXED | BR-ENH-02 |
| BR-03 | installment ≥2 งวด + sum=100% | FIXED | BR-ENH-02/03 |
| BR-04 | direct_payment disable PR/PO/Quotation/SO | FIXED | D05/BR-ENH-04 |
| BR-05 | deposit percent: value ≤100 | FIXED | BR-ENH-05 |
| BR-06 | credit: net_days >0 | FIXED | BR-ENH-10 |
| BR-07 | use_in ≥1 | FIXED | BR-ENH-08 |
| BR-08 | เปลี่ยน type → reset config (preserve code/name/use_in) | FIXED | BR-ENH-07 |
| BR-09 | credit lock immediate, direct = no trigger | FIXED | D02/LD-08 |
| BR-10 | after_deposit trigger เฉพาะ deposit | FIXED | BR-ENH-05 |
| BR-11 | Quotation มี payment term เฉพาะ S2C (proposal) | CONFIGURABLE | D01 |
| BR-12 | GRN/Ship trigger ตามประเภท (Prepay/Deposit รอ PV/Receipt) | DYNAMIC | D02 |
| BR-13 | Partial: ยอดชำระที่ GRN/Ship แต่ละรอบ | DYNAMIC | D10 |
| BR-14 | Deposit%/Installment% ปรับได้ที่ PO/SO | CONFIGURABLE | D08/D09 |

## §5.2 Validation Rules

| Field | Rule | Error Code |
|---|---|---|
| code | required, unique, uppercase | DUPLICATE_CODE |
| name | required | NAME_REQUIRED |
| installments | ≥2 + sum=100 | INSTALLMENT_SUM_INVALID |
| deposit_value | ≤100 if percent | DEPOSIT_PCT_EXCEEDED |
| net_days (credit) | >0 | CREDIT_DAYS_INVALID |
| use_in | ≥1 | USE_IN_REQUIRED |

## §5.3 Edge Cases

| ID | Case | Handling |
|---|---|---|
| EC-01 | code ซ้ำ | block + error field |
| EC-02 | installment ≠100% | block + แจ้งยอด |
| EC-03 | installment 1 งวด | ปุ่มลบ disabled ที่ 2 |
| EC-04 | deposit %>100 | block |
| EC-05 | ไม่เลือก use_in | block |
| EC-06 | เปลี่ยน type | reset config เฉพาะประเภท |
| EC-07 | direct_payment + PR/PO/SO | disable (แสดง "ไม่รองรับ") |
| EC-08 | ตั้ง default ซ้ำ type | ล้างเก่าอัตโนมัติ |
| EC-A2 | CSV row type ผิด | mark error, skip |
| EC-A3 | CSV replace ขณะมี default | default หาย — warn |
| EC-A4 | installment days ไม่เรียง | OQ-05 (validate optional) |
| EC-A5 | discount_days > net_days | warn (logically ผิด) |

## §5.4 Error Catalog

| Code | HTTP | Message (TH) |
|---|---|---|
| PAYMENT_TERM_NOT_FOUND | 404 | ไม่พบเงื่อนไขชำระเงิน |
| DUPLICATE_CODE | 422 | รหัสเงื่อนไขนี้มีอยู่แล้ว |
| INSTALLMENT_SUM_INVALID | 422 | สัดส่วนงวดต้องรวมเป็น 100% |
| DEPOSIT_PCT_EXCEEDED | 422 | มัดจำแบบ % ต้องไม่เกิน 100 |
| CREDIT_DAYS_INVALID | 422 | จำนวนวันเครดิตต้องมากกว่า 0 |
| USE_IN_REQUIRED | 422 | เลือกเอกสารที่ใช้อย่างน้อย 1 รายการ |
| NAME_REQUIRED | 422 | กรุณากรอกชื่อเงื่อนไข |

## §5.7 Data Classification Enforcement (D-CLASS)

- ทุก field = **Internal** (default) — enforce ผ่าน RLS tenant_id + role-based access (permission matrix §0.4)
- Audit (S06-03): ทุก mutation (create/update/archive/import) บันทึก before/after — immutable (S01-07)
- ไม่มี Confidential/Restricted/PII → ไม่ต้อง wire Policy Center Restricted Resources
