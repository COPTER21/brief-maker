# 07_LOCKED_DECISIONS — F-PAYMENT-TERM-001 เงื่อนไขการชำระเงิน

> Locked Decisions + Convention deviations

---

## §7.1 Locked Decisions (จาก Cheat Sheet D01-D15 + ENH FRD)

| LD | Decision | Source |
|---|---|---|
| LD-01 | Payment term ที่ PO/SO เท่านั้น (PR ไม่มี); S2C Quotation = proposal | D01 |
| LD-02 | GRN/Ship trigger ตามประเภท: Full Prepay/Deposit รอ PV/Receipt; rest = ทันที | D02 |
| LD-05 | เปลี่ยน payment type หลัง approve เอกสารไม่ได้; direct_payment ไม่ผ่าน PR/PO/QUO→SO | D05 |
| LD-08 | Deposit % inherit + adjustable ที่ PO/SO | D08 |
| LD-09 | Installment inherit + adjust %/due_date sum=100 | D09 |
| LD-10 | Partial Delivery: GRN sets pay amount แต่ละรอบ | D10 |
| LD-08b | Credit trigger = ทันที (locked) | ENH LD-08 |
| LD-15 | Installment ≠ Partial Delivery (คนละประเภท) | D15 |

## §7.2 Design Decisions (FRD-level)

| ID | Decision | Rationale |
|---|---|---|
| DD-01 | 1 master ใช้ร่วม P2P + S2C | ลดความซ้ำซ้อน — field trigger ตีความตามฝั่ง |
| DD-02 | use_in 8 docs แยก AP/AR + Payment Voucher/Receipt | คนละ feature/document จริง |
| DD-03 | Quotation เฉพาะฝั่งขาย | D01 (P2P ไม่มี payment term ที่ quotation) |
| DD-04 | trigger field รวม WH(S2C)/GRN(P2P)/Ship เป็น field เดียว | master เดียวรับทั้งสองฝั่ง — FRD note P2P=GRN, S2C=Warehouse/Ship |
| DD-05 | View page ใช้ view-drawer-tabbed (generic) ไม่ใช่ po-style | Master Data — ไม่มี approver/PDF/signature |
| DD-06 | WH/GRN trigger + use_in ตัดจาก list column | UX — column เยอะเกิน (BRD §14.6 deviation) |

## §7.3 Convention Deviations

| Deviation | Standard | Used | Reason |
|---|---|---|---|
| ENG global ID | ENG-NNN | ENG-PT-01/02 (scope-prefix) | ยังไม่ register CUBIC — assign global ID ตอน hand-off |

## §7.4 CUBIC Registration Candidates

- `installment-validator` (ENG-PT-01) — reusable P2P + Purchase Config
- `payment-trigger-resolver` (ENG-PT-02) — reusable P2P + Purchase Config

## §7.5 DOA Wire (Phase 4)

approver_role / approved_by / approval_chain = TODO placeholder — wire เข้า DOA engine เมื่อพร้อม (CUBE 4.0 governance — ไม่ hardcode approval)
