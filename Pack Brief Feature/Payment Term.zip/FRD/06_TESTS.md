# 06_TESTS — F-PAYMENT-TERM-001 เงื่อนไขการชำระเงิน

> Acceptance per FR + DoD

---

## §6.1 Acceptance Criteria

### AC-01 Create (F-PT-FN-01)
- [ ] สร้างได้ครบ 7 ประเภท
- [ ] code ซ้ำ → block + error
- [ ] use_in ว่าง → block
- [ ] บันทึกแล้ว status=active

### AC-02 Deposit config
- [ ] deposit_method 3 แบบ (percent/fixed/manual)
- [ ] percent value >100 → block
- [ ] manual → ซ่อน value field

### AC-03 Installment
- [ ] ≥2 งวด, sum=100 → pass
- [ ] sum≠100 → block + แจ้งยอด
- [ ] ลบเหลือ 2 → ปุ่มลบ disabled
- [ ] แต่ละงวดมี % + due_type + desc

### AC-04 use_in
- [ ] checklist 8 docs (group ซื้อ/ขาย)
- [ ] ≥1 บังคับ
- [ ] direct_payment disable PR/PO/Quotation/SO

### AC-05 Default
- [ ] ตั้ง default → ล้างเก่าใน type เดียวกัน
- [ ] แสดงดาวใน list

### AC-06 Status
- [ ] archive → status=archived (ไม่ลบ)
- [ ] reactivate → active

### AC-07 Type change
- [ ] เปลี่ยน type → reset config
- [ ] preserve code/name/use_in

### AC-08 CSV
- [ ] import validate ต่อ row
- [ ] replace ลบเก่าก่อน (warn)
- [ ] merge เพิ่ม

### AC-09 Trigger
- [ ] credit lock immediate
- [ ] direct = no trigger
- [ ] after_deposit เฉพาะ deposit

### AC-10 List/Search/Filter
- [ ] search code/name/name_en
- [ ] filter by type
- [ ] summary cards 6 ถูกต้อง

## §6.2 Definition of Done

- [ ] ทุก AC ผ่าน
- [ ] Validation server + client ตรงกัน
- [ ] Audit log ทุก mutation (S06-03)
- [ ] RLS tenant isolation
- [ ] approver placeholder ใส่ไว้ (รอ DOA)
- [ ] Data Classification = Internal ทุก field
- [ ] No JS error, Iron Rules pass (CI/icon/R31/R32/R33)
